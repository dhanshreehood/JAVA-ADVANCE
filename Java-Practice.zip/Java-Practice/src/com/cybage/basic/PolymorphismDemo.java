package com.cybage.basic;

	class A
	{
//		public void display()
//		{
//			System.out.println("class A's display method");
//		}
	}
	
	class B extends A
	{
		public void display()
		{
			System.out.println("class B's display method");
		}
	}
	
	//@Override
	public class PolymorphismDemo {
	 public static void main(String[] args) {
//		 A a=new A();
//		 a.display();
		 
		 B b=new B();
		 b.display();
		 
		 A a1=new B();// superclass is holding the object of subclass.
		 //a1.display(); //error will be shown
	 }
	}
