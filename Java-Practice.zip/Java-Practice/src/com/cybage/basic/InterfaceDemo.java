package com.cybage.basic;

interface MathOperations{ //interface
	float PI = 3.14f;
	abstract public void add(int n1, int n2);
	abstract public void sub(int n1, int n2); //if u dont provide implementation for abstract method it will give error.

}

class Calculator implements MathOperations{ //Implementation for interface method by using 'implements'.

	@Override
	public void add(int n1, int n2) { //defining method here for add
		System.out.println("Addition = " + (n1 + n2));
	}

	@Override
	public void sub(int n1, int n2) {  //defining method here for sub
		System.out.println("Subtraction = " + (n1 - n2));

	}	
}

public class InterfaceDemo {

	public static void main(String[] args) {
//		Calculator c = new Calculator(); //create object
//		c.add(44, 55); // calling method 
		
		MathOperations mOperations = new Calculator(); //reference var is MathOperation.
		mOperations.add(22, 33);
		mOperations.sub(22, 33);
		
		//MathOperations.PI = 44.34f; // it will provide error
		
		System.out.println(MathOperations.PI); //no need to create object, u can access it directly as shown here.

	}
}

// class can implement multiple methods.
//