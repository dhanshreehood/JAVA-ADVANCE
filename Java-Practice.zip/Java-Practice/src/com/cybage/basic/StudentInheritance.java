package com.cybage.basic;

public class StudentInheritance extends personInheritance{
	private int rollNo;
	private int marks;
	
	StudentInheritance(String name, String address, int rollNo, int marks)
	{
		super(name,address);
		this.rollNo=rollNo;
		this.marks=marks;
	}
	
	public int getRollNo() {
		return this.rollNo;
	}
	
	public int getMarks() {
		return this.marks;
	}
}
