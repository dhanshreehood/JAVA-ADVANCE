package com.cybage.basic;

//Method Overloading: same method, diff parameters. we can do this iun the same class.
class AddDemo{
	int add(int n1, int n2) {
		System.out.println("Add int: ");
		return n1 + n2;
	}
	
	float add(float n1, float n2) {
		System.out.println("Add float: ");
		return n1 + n2;
	}
	
	double add(double n1, double n2){
		System.out.println("Add double: ");
		return n1 + n2;
	}
	
	byte add(byte n1, byte n2){
		System.out.println("Add byte: ");
		return  (byte)(n1 + n2);
	}
	long add(long n1,long n2){
		System.out.println("Add long: ");
		return  (n1 + n2);
	}
}

public class StaticPolymorphism {

	public static void main(String[] args) {
		AddDemo addDemo=new AddDemo();
		System.out.println(addDemo.add(10, 20));
		System.out.println(addDemo.add(10.55, 20));
		System.out.println(addDemo.add(10.2f, 20.2));//Implicit typecasting is doing here, and lost of data is also occuring.
		System.out.println(addDemo.add((byte)10, 20));//Calls int method if only one is of int type
		System.out.println(addDemo.add((byte)10, (byte)20));//to call byte method- do typecasting of all the values
		System.out.println(addDemo.add(10522222, 2052222222));
		}

}
