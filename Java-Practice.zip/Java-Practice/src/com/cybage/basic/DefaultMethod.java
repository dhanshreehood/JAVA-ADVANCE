package com.cybage.basic;

interface MathOperations1{ //interface
	float PI = 3.14f;
	abstract public void add(int n1, int n2);
	abstract public void sub(int n1, int n2); //if u dont provide implementation for abstract method it will give error.
	
	//Default Method
	default void multiplication(int n1,int n2) { //without modifying ur implementation class u can add new method.
		System.out.println("multiplication="+(n1*n2));
	}
	
	static void greet() {
		System.out.println("Hello in static");
	}
}

class Calculator1 implements MathOperations1{ //Implementation for interface method by using 'implements'.

	@Override
	public void add(int n1, int n2) { //defining method here for add
		System.out.println("Addition = " + (n1 + n2));
	}

	@Override
	public void sub(int n1, int n2) {  //defining method here for sub
		System.out.println("Subtraction = " + (n1 - n2));
	}	
	
	@Override
	public void multiplication(int n1, int n2) {  //defining method here for multiplication, while overriding u can't reduce the visibility; by using public. 
		System.out.println("Override Multiplication in subclass");
	}	
}

public class DefaultMethod {

	public static void main(String[] args) {
//		Calculator c = new Calculator(); //create object
//		c.add(44, 55); // calling method 
		
		MathOperations1 mOperations = new Calculator1(); //reference var is MathOperation.
		mOperations.add(22, 33);
		mOperations.sub(22, 33);
		mOperations.multiplication(46, 45); //for default object is required.

		//MathOperations1.PI = 44.34f; // it will provide error
		
		System.out.println(MathOperations1.PI); //no need to create object, u can access it directly as shown here.
		MathOperations1.greet();
	}
}

// class can implement multiple methods.
//