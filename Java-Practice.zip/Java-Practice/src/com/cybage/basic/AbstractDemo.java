package com.cybage.basic;

//	class Shape{
//		int l,b;
//		public void area()
//		{
//			System.out.println("can't define area for Shape");
//		}
//	}
//	

	abstract class Shape{ 
		int l,b;
		 Shape(int length,int breadth) {
			this.l=length;
			this.b=breadth;
		}
		abstract public void area(); //Abstract Method
	}

//	if you don't want to do implementation, use abstract 
//	abstract class Rectangle extends Shape
	class Rectangle extends Shape
	{
		 Rectangle(int length, int breadth)
		{
			super(length,breadth);
		}
		
		@Override
		public void area()
		{
			System.out.println("Area of Rectangle is:"+(l*b));
		}
	}
	class Triangle extends Shape
	{ 
		Triangle(int length, int breadth) {
			super(length, breadth);
		}

		@Override
		public void area()
		{
			System.out.println("Area of Triangle is:" + 0.5*(l*b));
		}
	}
	public class AbstractDemo {
	
		public static void main(String[] args) {
		Shape sh=new Rectangle(23,34);
			sh.area();
		}	
	}
