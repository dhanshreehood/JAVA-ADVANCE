package com.cybage.basic;

public class BookDemo {

	public static void main(String[] args) {
		Book b=new Book(1002,"C","Maina Devi Kumar Tirupathi Vellyam venkateshwar raju");
		
		System.out.println(b.toString());
		System.out.println(b); //by default it takes toString()
		
		System.out.println(b.getISBN());
		System.out.println(b.getTitle());
		System.out.println(b.getAuthor());
	}
}


