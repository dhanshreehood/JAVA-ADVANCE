package com.cybage.basic;

@FunctionalInterface // it will check that functional interface contains only one abstract method.
interface Moperation{
	public int add(int n1, int n2);
}

public class LambdaAdd { //lambda works only with functional interface.

	public static void main(String[] args) {
		Moperation m=(int n1, int n2)->{ System.out.println("Addition: " + (n1 + n2));
		return n1;};
		m.add(10, 5);
	};
}
