package com.cybage.basic;

public class GarbageC {

	public static void main(String[] args) {
		Book b=new Book(1002,"C","Maina Devi Kumar Tirupathi Vellyam venkateshwar raju");
		System.out.println(b);
		b=null;
		System.gc(); //Garbage Collector Syntax	
	}
}


