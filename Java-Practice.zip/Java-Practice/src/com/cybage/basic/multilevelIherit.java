package com.cybage.basic;

public class multilevelIherit {

	public static void main(String[] args) {
		multilevelIherit  multi=new multilevelIherit();
		System.out.println("X's constructor");

	}

}
