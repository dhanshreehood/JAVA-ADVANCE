package com.cybage.basic;

interface Vehicle{ //interface
	public void type(String t);
}

class Car implements Vehicle{ //Implementation for interface method by using 'implements'.

	@Override
	public void type(String t) { //defining method here for color
		System.out.println("Car Type is"+ t);
	}

class Bike implements Vehicle{
	@Override
	public void type(String t) { 
		System.out.println("Override Vehicle Type in subclass = " + t);
	}	
}


 	class VehicleInterface {

	public void main(String[] args) {
		Vehicle c = new Car();
		Bike b = new Bike(); 
		c.type("Maruti Suzuki");
		b.type("Harley Davidson");
	}
}
}