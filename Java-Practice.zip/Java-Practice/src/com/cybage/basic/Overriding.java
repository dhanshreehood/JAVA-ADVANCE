package com.cybage.basic;
//u can't reduce the visibility while overriding the method.
	 	class personInheritance2 { //it cant be done in the same ; superclass
		private String name;
		private String address;
		 
		personInheritance2(String name, String address)
		{
			this.name=name;
			this.address=address;
		}
		
		public String getInfo() {
			return "Name = "+ this.name + "Address: " + this.address; 
		}
	}
	

		class StudentInheritance2 extends personInheritance2{ //subclass
		private int rollNo;
		private int marks;
		
		StudentInheritance2(String name, String address, int rollNo, int marks)
		{
			super(name,address); //super must be the first statement of ur sub-class; then n only it can initialize it's own member.var 
			this.rollNo=rollNo;
			this.marks=marks;
		}
	
		public String getInfo() {
//			return "Roll no. = "+ this.rollNo + " Marks: " + this.marks;
			return super.getInfo()+ "Roll no. = "+ this.rollNo + " Marks: " + this.marks; // if want to access superclass var which is personInheritnace is here then we have to use super.
		}
	}


	public class Overriding {
	
		public static void main(String[] args) {
			
			personInheritance2 person2=new personInheritance2("Anarkali", "Agra");
			System.out.println(person2.getInfo());
	
			//sub-class
			StudentInheritance2 student2=new StudentInheritance2("Anarkali", "Agra", 472, 20);
			System.out.println(student2.getInfo());
			
			personInheritance2 p = new StudentInheritance2("Akbar", "Delhi", 420, 99); // super class can hold the object of subclass but vice versa is not possible
			System.out.println(p.getInfo());
		}
	
	}


