package com.cybage.basic;

@FunctionalInterface
interface Greeting{
//	public void greet();
//	public void greet(String m);
	public String greet(String m);
}
public class LambdaDemo {
	public static void main(String[] args) {
//		Greeting g=()->{System.out.println("Lambda Expression");}; //for single statement u can skip curly braces.
//		Greeting g=(String m)->System.out.println(m); //single parameter, u cn skip ()
//		Greeting g=m->System.out.println(m); //single parameter = u cn skip ()
		
//		Greeting g=m->{return m;};
//		Greeting g=m->return m; //error without curly
//		Greeting g=m->m;
		
//		g.greet("Parametered Passed value");		
//		System.out.println(g.greet("Hello Java from public String."));
		Greeting g=m->{System.out.println(m); 
		return m;};
	}
}
