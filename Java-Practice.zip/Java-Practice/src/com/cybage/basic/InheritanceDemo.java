package com.cybage.basic;

public class InheritanceDemo {

	public static void main(String[] args) {
		personInheritance person=new personInheritance("Anarkali", "Agra Disco");
		System.out.println(person.getName() + " " + person.getAddress());

		StudentInheritance student=new StudentInheritance("Anarkali", "Agra Disco", 472, 10);
		System.out.println(student.getName());
		System.out.println(student.getAddress());
		System.out.println(student.getMarks());
		System.out.println(student.getRollNo());

	}

}
