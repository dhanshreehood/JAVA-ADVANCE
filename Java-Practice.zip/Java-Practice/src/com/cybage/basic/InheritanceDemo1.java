package com.cybage.basic;

//		final class personInheritance1 // final prevents class to extend; *** string is final class defined in java.l package
	 	class personInheritance1 {
		private String name;
		private String address;
		 
		personInheritance1(String name, String address)
		{
			this.name=name;
			this.address=address;
		}
		
		public String getName() {
			return this.name;
		}
		 
		
		public String getAddress() {
			return this.address;
		}
	}
	

		class StudentInheritance1 extends personInheritance1{ 
		private int rollNo;
		private int marks;
		
		StudentInheritance1(String name, String address, int rollNo, int marks)
		{
			super(name,address); //super must be the first statement of ur sub-class; then n only it can initialize it's own member.var 
			this.rollNo=rollNo;
			this.marks=marks;
		}
		
		public int getRollNo() {
			return this.rollNo;
		}
		
		public int getMarks() {
			return this.marks;
		}
	}


	public class InheritanceDemo1 {
	
		public static void main(String[] args) {
			
			personInheritance1 person1=new personInheritance1("Anarkali", "Agra");
			System.out.println("Name: " + person1.getName() + " Address: " + person1.getAddress());
	
			StudentInheritance1 student1=new StudentInheritance1("Anarkali", "Agra", 472, 10);
			System.out.println(student1.getName());
			System.out.println(student1.getAddress());
			System.out.println(student1.getMarks());
			System.out.println(student1.getRollNo());
	
		}
	
	}


