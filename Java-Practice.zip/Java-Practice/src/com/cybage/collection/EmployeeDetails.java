package com.cybage.collection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class EmployeeDetails {

	public static void main(String[] args) {
		List<Employee> employeeList= new ArrayList<Employee>(); //from Employee class -diff file named Employee.java
		employeeList.add(new Employee(1000,"Shraddha",900));
		employeeList.add(new Employee(1001,"Dhanshree",60000));
		employeeList.add(new Employee(1002,"Nainamma",70000));
		employeeList.add(new Employee(1003,"Anna",80000));
		employeeList.add(new Employee(1004,"Appa",50000));
		employeeList.add(new Employee(1005,"Akka",20000));
		
//		System.out.println(employeeList);
		
//		comparable interface
		Collections.sort(employeeList);	
		System.out.println("comparable interface: " + employeeList);
		
//		Comparator - Functional Interface; we can use Lambda exp.
//		Collections.sort(employeeList,(e1,e2)->e1.getSalary()-e2.getSalary()); //Employee salary sorting
//		System.out.println("comparator interface: " + employeeList);
				
		Collections.sort(employeeList, (e1, e2)->e1.getEmployeeName().compareTo(e2.getEmployeeName())); //name sorting -compareTo; preferable
	}
}