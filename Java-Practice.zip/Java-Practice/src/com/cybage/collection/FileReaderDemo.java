package com.cybage.collection;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class FileReaderDemo {

	public static void main(String[] args) {
//		try(FileReader sourceStream= new FileReader("E:\\text.txt"))
//		{
//			int temp;
//			while((temp = sourceStream.read()) != -1)
//			{
//				System.out.print((char)temp);
//			}
//		}
		
//		//for reading multiple lines
		try(FileReader sourceStream= new FileReader("E:\\text.txt");
				BufferedReader br = new BufferedReader(sourceStream);)
		{
			String data;
			while((data=br.readLine())!= null)
			{
				System.out.println(data);
			}
		}
		
			catch (IOException e) 
			{
				e.printStackTrace();
			}
	}
}
