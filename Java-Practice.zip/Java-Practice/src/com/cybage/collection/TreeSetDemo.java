package com.cybage.collection;
import java.util.TreeSet;
import java.util.Set;
public class TreeSetDemo {

	public static void main(String[] args) {
	Set<Integer> numSet=new TreeSet<Integer>(); //HashSet - unordered

	numSet.add(24); 
	numSet.add(34); 
	numSet.add(56);
	numSet.add(56);
	numSet.add(24); //does not take duplicate value
	numSet.add(16);
//	numSet.add(null); //will give error
//	numSet.add(null);
	
	System.out.println(numSet);
	
	}
}
