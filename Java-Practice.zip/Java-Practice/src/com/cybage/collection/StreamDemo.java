package com.cybage.collection;
import java.util.Collection;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.Arrays;

public class StreamDemo {

	public static void main(String[] args) {
		List<Integer> intlist=Arrays.asList(2,3,4,6,78,84,489,45);
//		intlist.stream().filter((n)->n>50).forEach((n)->System.out.println(n));// convert list collection to stream
//		intlist.stream().filter((n)->n<50).forEach(System.out::println);
	
		Stream<Integer> stream = intlist.stream();
		Stream<Integer> filteredStream = stream.filter(n->n>50);
		filteredStream.forEach(System.out::println);
//		filteredStream.forEach(System.out::println); //illegALStateException
		
		intlist.stream().filter((n)->n>50).forEach(System.out::println);
		List<Integer> newList = intlist.stream().filter((n)->n>50).collect(Collectors.toList());
		System.out.println(newList);
		
		double avg = intlist.stream().map(n->n*2).collect(Collectors.averagingInt(n->n));
		System.out.println("Average = " + avg);

//		sorted()
		intlist.stream().sorted().collect(Collectors.toList());

//		reduce()
		int result=intlist.stream().reduce(0,(n1,n2)->n1+n2);
		System.out.println("result = " + result);
		
		List<Employee> employeeList= new ArrayList<Employee>(); //from Employee class -diff file named Employee.java
		employeeList.add(new Employee(1000,"Shraddha",900));
		employeeList.add(new Employee(1001,"Dhanshree",60000));
		employeeList.add(new Employee(1002,"Nainamma",70000));
		employeeList.add(new Employee(1003,"Anna",80000));
		employeeList.add(new Employee(1004,"Appa",50000));
		employeeList.add(new Employee(1005,"Akka",20000));
		
		//get employee whose salary is greater than 50000
		List<Employee> newEmployee = employeeList.stream().filter(emp->emp.getSalary()>50000).collect(Collectors.toList());
		System.out.println("Employee Salary above 50000 = \n" + newEmployee);
		
		//get employee name starting from "A"
		List<Employee> newEmployeeName = employeeList.stream().filter(emp->emp.getEmployeeName().startsWith("A")).collect(Collectors.toList());
		System.out.println(newEmployeeName);
		
		//each value will get multiplied to the list value
		List<Integer> newListMultiply=intlist.stream().map(n->n*2).collect(Collectors.toList());
		System.out.println(newListMultiply);
		
		//10% hike in salary of employee 
		List<Integer> newEmployeeSalaryHike = employeeList.stream().map(n->n.getSalary()).collect(Collectors.toList());
		System.out.println(newEmployeeSalaryHike);				
	}
}