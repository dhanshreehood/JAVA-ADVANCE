package com.cybage.collection;
import java.util.Map;
import java.util.HashMap;
public class HashMapDemo {

	public static void main(String[] args) {
		Map<Integer, String> map=new HashMap<Integer, String> ();
		Map<Integer, String> map2=new HashMap<Integer, String> ();

		map.put(1, "Dhanshree");
		map.put(2, "Darling");
		map.put(3, "Rama");
		map.put(4, "Vikram");
		map.put(5, "Aarya");
		
		
//		basic operation
		System.out.println(map);
		System.out.println(map.get(2));
		System.out.println(map.remove(2));
		System.out.println(map.containsKey(3));
		System.out.println(map.size());
		System.out.println(map.containsValue("Rama"));
		System.out.println("after isEmpty() : " + map.isEmpty());
		
//		collection views
		System.out.println(map.keySet());
		System.out.println(map.values());
		
//		bulk operation
		map2.putAll(map);
		System.out.println(map2);
		
		map2.clear();
		System.out.println(map2);
		
		System.out.println(map2.isEmpty());//basic operator to check whether map 2 is empty or not
	}

}
