package com.cybage.collection;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class SerializationDemo {
	public static void main(String[] args) {
		Student student= new Student(101,"Amit",70);
		
		try(FileOutputStream fos=new FileOutputStream("E:\\\\Temp\\\\student.text");
				ObjectOutputStream oss=new ObjectOutputStream(fos))
		{
			oss.writeObject(student);
			System.out.println("done");
		}
		catch (IOException e)
		{
		
		}
	}
}