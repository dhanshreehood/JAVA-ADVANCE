package com.cybage.collection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ArrayListMethod {

	public static void main(String[] args) {
		List<String> nameList =new ArrayList<>(); //generic- <> in which u specify the datatype of items u gonna store in the list.
		
		System.out.println("size of the list before adding items: " + nameList.size()); //to check  size of the list
		nameList.add("Vijaya");
		nameList.add("John");  //we can add duplicate value in List
		nameList.add("John");
		nameList.add("John");
		nameList.add("John");
		nameList.add("John");
		nameList.add("John");
		nameList.add("Aiyappa");
		nameList.add("Siyaraman");
		nameList.add("Dhanshree");
		
		//for each
		for(String name: nameList)
			System.out.println(name);
		Iterator<String> iteratorObj = nameList.iterator();
		
		while(iteratorObj.hasNext()) {
			String name= iteratorObj.next();
			System.out.println(name);
		}
		
		System.out.println("size of the list after adding items:" + nameList.size());
		System.out.println(nameList);
		
		System.out.println(nameList.contains("John")); //checks wheather List contains the value or not and returns boolean value 
		
		nameList.remove("Vijaya");
		System.out.println("After removing vijaya: " + nameList);
		
		System.out.println("Get method: " + nameList.get(3)); //retrieving value by using get method by using index.
		
		nameList.set(2, "Superman");
		System.out.println("After setting name : " + nameList);
		
		int index = nameList.indexOf("John");
		System.out.println("index of john: " + index);
		
//		String names[] = (String[])nameList.toArray();	
		
	}

}
