package com.cybage.collection;

import java.nio.file.Paths;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Files;

public class PathDemo {

	public static void main(String[] args) throws IOException {
//		Path path = Paths.get("E:\\\\Temp\\\\student.text");
//		Path dest = Paths.get("E:\\\\Temp\\\\student.text");

/*		
		System.out.println("Number of Nodes:"+path.getNameCount());
		System.out.println("File name:"+path.getFileName());
		System.out.println("File Root:"+path.getRoot());
		System.out.println("File Parent:"+path.getParent());
*/
//		Files.write(path,"Hello From NIO".getBytes(StandardCharsets.UTF_8));
		
		Path path = Paths.get("E:\\Java 2022\\Java-Training\\Temp\\test");
		Path dest = Paths.get("E:\\Java 2022\\Java-Training\\Temp\\testCreate");

		Files.copy(path, dest);
	}
}