package com.cybage.collection;
import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.function.Predicate;
import java.util.function.*;

public class FunctionalInterfaceDemo {

	public static void main(String[] args) {
		//categories of Functional Interface
		//Supplier function
		Supplier<String> supplier=()->"Hello from Java";
		System.out.println(supplier.get());
		
		Supplier<Employee> empSupplier=()-> new Employee(1001," John",40000);
		System.out.println(empSupplier.get());
		
		//Consumer function
		Consumer<String> consumer=(msg)->System.out.println(msg);
		consumer.accept("Hello Consumer");
	
		//Predicate function- very frequently used
		Predicate<Integer> predicate=(n)->n>20; //returns boolean value
		System.out.println(predicate.test(2));
		
		// Functional<T,R>--T:Type of obj it will pass; R: Type of obj it will return.
		Function<String, Integer> function=(msg)->msg.length();
		System.out.println(function.apply("Hello from Java"));
	}

}
