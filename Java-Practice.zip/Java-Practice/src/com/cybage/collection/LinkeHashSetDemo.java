package com.cybage.collection;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.Iterator;
public class LinkeHashSetDemo {

	public static void main(String[] args) {
	Set<Integer> numSet=new LinkedHashSet<Integer>(); //HashSet - ordered

	numSet.add(24); 
	numSet.add(34); 
	numSet.add(56);
	numSet.add(56);
	numSet.add(24); //does not take duplicate value
	numSet.add(16);
	numSet.add(null);
	numSet.add(null);
	
	System.out.println(numSet);
	
//	for each loop
/*	for(Integer name: numSet)
		System.out.println(name);
*/
	
//	Iterator
/*	Iterator<Integer> iterator = numSet.iterator();
	while(iterator.hasNext()) {
		Integer name= iterator.next();
		System.out.println(name);
	}
*/		
	
//	forEach Method-
	numSet.forEach((name)->System.out.println(name));
	}
}
