package com.cybage.collection;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class DeSerializationDemo {
	public static void main(String[] args) {
		
		try(FileInputStream fis=new FileInputStream("E:\\\\Temp\\\\student.text");
				ObjectInputStream ois=new ObjectInputStream(fis))
		{
			System.out.println(ois.readObject());
		}
		catch (IOException e)
		{
		
		}
	}
}
