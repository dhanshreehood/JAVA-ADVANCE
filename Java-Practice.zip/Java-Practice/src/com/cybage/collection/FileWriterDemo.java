package com.cybage.collection;

import java.io.IOException;
import java.io.FileReader;
import java.io.FileWriter;

public class FileWriterDemo {

	public static void main(String[] args) {
		try(FileReader sourceStream= new FileReader("E:\\text.txt");
				FileWriter fileWrite = new FileWriter("E:\\Temptext2.txt"))
		{
			int temp;
			while((temp = sourceStream.read()) != -1)
			{
				System.out.print((char)temp);
				fileWrite.write(temp);
			}
		}	
		catch (IOException e) 
		{
			e.printStackTrace();
		}
}
}