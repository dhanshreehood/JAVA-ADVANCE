package com.cybage.collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class ArrayListDemo {

	public static void main(String[] args) {
		List<String> nameList =new ArrayList<>(); //generic- <> in which u specify the datatype of items u gonna store in the list.
		
		System.out.println("size of the list before adding items: " + nameList.size()); //to check  size of the list
		nameList.add("Vijaya");
		nameList.add("John");  //we can add duplicate value in List
		nameList.add("John");
		nameList.add("John");
		nameList.add("John");
		nameList.add("John");
		nameList.add("John");
		nameList.add("Aiyappa");
		nameList.add("Siyaraman");
		nameList.add("Dhanshree");
		
//		collection class - only works for list
//		Collections.sort(nameList); //prints list in a sorted method
//		Collections.reverse(nameList); // prints elements in reverse order

/*		int count = Collections.frequency(nameList, "DhupAggrabatti");
		int count1 = Collections.frequency(nameList, "John");

		System.out.println("Count for DhupASggarbatti: " + count);
		System.out.println("Count for John: "+ count1);
*/	
		
//		for-each loop-old approach
/*		for(String name: nameList)
			System.out.println(name);
*/		
		
//		using Iterator-old approach
/*			Iterator<String> iteratorObj = nameList.iterator();
 			while(iteratorObj.hasNext()) {
			String name= iteratorObj.next();
			System.out.println(name);
		}
*/
		
//		forEach() method-latest
		nameList.forEach((name)->System.out.println("forEach() : " + name));
	}
}