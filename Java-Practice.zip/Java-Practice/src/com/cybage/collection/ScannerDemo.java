package com.cybage.collection;
import java.util.Scanner;

public class ScannerDemo {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter integer:");
		int n1= sc.nextInt();
		System.out.println("Enter float:");
		float f1=sc.nextFloat();
		System.out.println("Enter String:");
		String msg = sc.nextLine();
		sc.next();
		String string= sc.next();
		System.out.println(n1);
		System.out.println(f1);
		System.out.println(string);
		}
}