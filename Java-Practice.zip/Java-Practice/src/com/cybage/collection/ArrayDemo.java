package com.cybage.collection;
import java.util.Arrays;
import java.util.List;

public class ArrayDemo {
	public static void main(String[] args) {
		Integer arr[]= {4,5,6,8,4};
//		List<Integer> list=Arrays.asList(3,5,7,3,5);
		
//		conversion of array into list
		List<Integer> numList= Arrays.asList(arr);
		System.out.println(numList);
		
		Arrays.sort(arr);
		
		
//		for-each loop
		for(int n:arr) {
			System.out.println(n);
		}
		
//		forEach()
		numList.forEach((a)-> System.out.println(a));
}
}