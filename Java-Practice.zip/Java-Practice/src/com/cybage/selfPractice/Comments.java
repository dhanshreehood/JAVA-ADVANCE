package com.cybage.selfPractice;

public class Comments {

	public static void main(String[] args) {
//		single line comment
		
/*		multiline comment
		printed by 
		Dhanshree Hood
*/		
	}

}
