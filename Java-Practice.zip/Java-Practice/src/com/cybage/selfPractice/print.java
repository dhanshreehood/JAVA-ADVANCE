package com.cybage.selfPractice;

public class print {

	public static void main(String[] args) {
//		System- built in java which contains useful java members.
//		out- output; in-input
//		println-print line.
//		will print line on the next line
		System.out.println("Hello World");
//		System.out.println(Without being inside quotation it will give u error.);
		System.out.println(3+8);
		
//		print- will print line on the same line 
		System.out.print("Hello");
		System.out.print("World");
	}

}
