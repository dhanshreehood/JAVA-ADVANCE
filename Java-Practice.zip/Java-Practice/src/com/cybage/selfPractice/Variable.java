package com.cybage.selfPractice;

public class Variable {

	public static void main(String[] args) {
//		variable types
		int a = 1;
		float fn = 1.22f;
		char c = 'D';
		String s = "String Value";
		boolean b = true;
		
//		declaring type and value
		int number = 10;
		System.out.println(number);
		
//		declaring var first then initializing value later
		int number2;
		number2 = 20;
		System.out.println(number2);
		
//		overwriting value
		int num = 60;
		num = 100; //will overwrite
		System.out.println(num);
		
//		+ operator to combine both text and variable in text case
		String name = "Dhanshree Hood";
		System.out.println("Hello " + name);
		
//		+ operator in numeric case
		int n3 = 12;
		float n4 = 2.55f;
		System.out.println(n3 + n4); //float value will be return
		
//		multiple line variable
		int m1 = 10;
		int m2 = 20;
		float m3 = 5.5f;
		System.out.println(m1 + m2 + m3 );
		
//		for same value
		int p1, p2, p3;
		p1 = p2 = p3 = 50;
		System.out.println(p1);
		System.out.println(p2);
		System.out.println(p3);
		
//		identifiers
/*		1. it must be unique names
		2. it can be short name or discriptive
		3. discriptive names r more recommended to make code more readable and maintainable
*/	
		float minute = 3.30f; //more readable as compare to-
		float m = 3.30f;
 	}

}
