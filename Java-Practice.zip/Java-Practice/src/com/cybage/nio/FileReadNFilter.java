package com.cybage.nio;
import java.util.List;

import com.cybage.basic.staticClass;

import java.nio.file.paths;
import java.nio.file.Paths;
import java.nio.file.path;

public class FileReadNFilter {
	public static void main(String[] args) {
		Path filePath = Paths.get("")
	}

}
