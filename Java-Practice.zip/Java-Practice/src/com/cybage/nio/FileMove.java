package com.cybage.nio;

public class FileMove {

	public static void main(String[] args) {
		
	}

}
