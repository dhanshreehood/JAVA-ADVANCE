package com.cybage.nio;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.CopyOption;


public class Copy {

	public static void main(String[] args) throws IOException {
		Path source = Paths.get("E:\\Temptext2.txt");
		Path destination = Paths.get("E:\\text1.txt");
/*		Files.copy(source, destination, StandardCopyOption.REPLACE_EXISTING);
		System.out.println("Done");
*/		Path dest
		
		Files.move(source,destination);
	}
}