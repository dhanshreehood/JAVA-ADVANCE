package com.cybage.exception;

//public class AgeException extends Exception{//it will throw checked exception
	public class AgeException extends RuntimeException{//it will throw unchecked exception

	public AgeException(String msg) {
		super(msg);
	}
} 
