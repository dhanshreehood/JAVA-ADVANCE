package com.cybage.exception;

import java.io.IOException;

public class ThrowsException {
	public static void demo() throws IOException //it is a checked exception u need to specify using throws
	{
		throw new IOException();
	}

	public static void main(String[] args) throws IOException { // in case of direct exception u have to specify throw
//	try {
//		demo();
//	}
//	catch(IOException e)
//	{
//		e.printStackTrace();
//		}
		demo();
	}		
	}