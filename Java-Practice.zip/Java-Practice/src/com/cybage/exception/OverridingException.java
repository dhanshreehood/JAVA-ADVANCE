package com.cybage.exception;

import java.io.IOException;

class Parent{//superclass
	public void OverrideException() throws IOException {
		throw new IOException();
	}
}

class Child extends Parent{ //subclass
	@Override
	public void OverrideException() throws IOException{
		throw new IOException();
	}
}