package com.cybage.exception;

 

public class MethodException {

}
