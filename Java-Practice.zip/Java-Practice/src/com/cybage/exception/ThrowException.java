package com.cybage.exception;

public class ThrowException {
//	we can handle directly here or in main
	public static void demo(){
		System.out.println("Inside Demo");
		int a = 10/0;
		System.out.println("a = " + a);
	}	

	public static void main(String[] args) {
		
		try {
			demo();			
		}
		
		catch(ArithmeticException e) {
			e.printStackTrace();
		}
	}
		
/*		try {
			throw new NullPointerException();
		}
		
		catch(NullPointerException e){
			e.printStackTrace();
		}
		System.out.println("After Catch....");
	}
*/
}
