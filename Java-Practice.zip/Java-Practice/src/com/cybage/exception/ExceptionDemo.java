package com.cybage.exception;

public class ExceptionDemo {

	public static void main(String[] args) {
		try { //code that generate error will be written under try block.
		
		int a = 10;
//		int b = 0;
//		int c = a / b;		 //after this line programme will terminate.
		
		int l=args.length;
		int b=l;
		int c=a/l;
		int arr[]=new int[5];
		System.out.println(arr[5]);

		 System.out.println("C: " + c); //normally it will throw exception.
	}
		
//		catch(Exception) //it handles top most exception
//		catch(ArithmeticException z) { //z is the exception object; handling specific arithmetic exception.
//			System.out.println(z.getMessage());
//			z.printStackTrace();
//		}
//		
//		catch (ArrayIndexOutOfBoundsException e) {
//			System.out.println(e.getMessage());
//			e.printStackTrace();
//		}
		
		catch (ArrayIndexOutOfBoundsException | ArithmeticException |NullPointerException e) { //multiple exception in single catch box.
			System.out.println(e.getMessage());
			e.printStackTrace();
		}	
		
		catch (Exception a) { //we can't state it as first catch bcoz it will throw unreachable code. subclass exception will come first and then at the end super class will be defined.
			System.out.println(a.getMessage());
			a.printStackTrace();
		}

		
		finally { //it will execute code in all situation
			System.out.println("Finally Block Executed.");
		}
			System.out.println("After catch block");
	}
}
