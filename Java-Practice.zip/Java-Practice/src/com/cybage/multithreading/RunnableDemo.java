package com.cybage.multithreading;

public class RunnableDemo {

	public static void main(String[] args) {
//		Runnable runnableObj=()->{System.out.println("created by using Lambda expression");};
		Runnable runnableObj=()->{System.out.println(Thread.currentThread().getName());}; //getName() returns name of the Thread, running currently. 

		Thread t1 = new Thread(runnableObj, "Demo of Thread");
		t1.start();
	}
}