package com.cybage.multithreading;

class FirstBlock{
		public void display(String msg)
		{
			System.out.print("[" + msg);
			try {
				Thread.sleep(2000);
			}
			catch(InterruptedException e){
				e.printStackTrace();
			}
			
			System.out.print("]");
		}
	}

class SecondBlock extends Thread{
	String msg;
	FirstBlock fObj;
	SecondBlock (FirstBlock fp, String str) //initializing var
	{
		this.fObj = fp;
		this.msg=str;
		start();
	}
	public void run() {
		synchronized(fObj) {  //Synchronized Block
			fObj.display(msg);
		}
	}
}
	
public class SynchronizedBlock {

	public static void main(String[] args) {
	First fObj = new First();
	Second s1 = new Second(fObj,"welcome");
	Second s2 = new Second(fObj,"new");
	Second s3 = new Second(fObj,"Programmer");
	}
}