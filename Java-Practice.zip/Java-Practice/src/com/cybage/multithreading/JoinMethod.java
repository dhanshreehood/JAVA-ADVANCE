package com.cybage.multithreading;

class JoinThreadDemo extends Thread {
	public JoinThreadDemo(String name) {
		super(name);
	}

	@Override
	public void run() {
//		System.out.println("Program is running in Thread");
		for (int i = 0; i <= 5; i++) {
			System.out.println(Thread.currentThread().getName() + " " + i); // returns the object of currently running thread
			try{
				Thread.sleep(7000); //sleep method- will suspend current execution of thread for specific period. 
				}
			catch(InterruptedException e){
					e.printStackTrace();
				}
		}
	}
}

public class JoinMethod {

	public static void main(String[] args) throws InterruptedException {
		System.out.println(Thread.currentThread().getName()); // returns the object of currently running
		JoinThreadDemo thread1 = new JoinThreadDemo("Thread1");
		JoinThreadDemo thread2 = new JoinThreadDemo("Thread2");

		thread2.start(); // after start thread will be in runnable state, ready to run but waiting for cpu
		
		//Join Method- allows one thread to wait until another thread completes its execution. I
		thread2.join();  //by using this we can ctrl their execution
		thread1.start(); //after only thread2 cmplts it's execution it will run.
	}
}