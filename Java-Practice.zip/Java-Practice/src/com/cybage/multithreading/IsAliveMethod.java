package com.cybage.multithreading;

class IsAliveThreadMethod extends Thread {
	public IsAliveThreadMethod(String name) {
		super(name);
	}

	@Override
	public void run() {
//		System.out.println("Program is running in Thread");
		for (int i = 0; i <= 5; i++) {
			System.out.println(Thread.currentThread().getName() + " " + i); // returns the object of currently running thread
		}
	}
}

public class IsAliveMethod {

	public static void main(String[] args) throws InterruptedException {
		System.out.println(Thread.currentThread().getName()); // returns the object of currently running
		IsAliveThreadMethod thread1 = new IsAliveThreadMethod("Thread1");
		IsAliveThreadMethod thread2 = new IsAliveThreadMethod("Thread1");

		thread1.start(); // after start thread will be in runnable state, ready to run but waiting for cpu
		System.out.println("Status of thread1: " + thread1.isAlive() + "\n");

		thread1.join(); 
		//isAlive()- check whether the thread has finished running before using any attributes that the thread can change.
		System.out.println("Status of thread1 after execution: " + thread1.isAlive() + "\n");
		
		thread2.start();
	}
}

//once run() terminates it will be in dead state.