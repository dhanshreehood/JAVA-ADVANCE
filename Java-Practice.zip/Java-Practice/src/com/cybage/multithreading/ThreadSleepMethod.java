package com.cybage.multithreading;

class SleepThreadDemo extends Thread {
	public SleepThreadDemo(String name) {
		super(name);
	}

	@Override
	public void run() {
//		System.out.println("Program is running in Thread");
		for (int i = 0; i <= 5; i++) {
			System.out.println(Thread.currentThread().getName() + " " + i); // returns the object of currently running thread
			try{
				Thread.sleep(7000); //sleep method- will suspend current execution of thread for specific period. 
				}
			catch(InterruptedException e){
					e.printStackTrace();
				}
		}
	}
}

public class ThreadSleepMethod {

	public static void main(String[] args) {
		System.out.println(Thread.currentThread().getName()); // returns the object of currently running
		SleepThreadDemo thread1 = new SleepThreadDemo("Thread1");
		SleepThreadDemo thread2 = new SleepThreadDemo("Thread2");

		thread1.start(); // after start thread will be in runnable state, ready to run but waiting for cpu
		thread2.start();
	}
}