package com.cybage.multithreading;

public class PriorityMethod {

	public static void main(String[] args) {
		
		Runnable runnableObj=()->{
//			Thread.currentThread().setPriority(10);
//			Thread.currentThread().setPriority(Thread.MAX_PRIORITY);
//			Thread.currentThread().setPriority(Thread.MIN_PRIORITY);
			Thread.currentThread().setPriority(Thread.NORM_PRIORITY);

			System.out.println(Thread.currentThread().getPriority());
		};
		
		Thread threadObj = new Thread(runnableObj, "Thread Name");
		threadObj.start();
	}

}
