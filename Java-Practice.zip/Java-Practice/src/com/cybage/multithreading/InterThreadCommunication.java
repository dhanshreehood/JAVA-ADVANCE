package com.cybage.multithreading;
//producer-produces the data; notifies after  producing tha dat to consumer.
//consumer- consumes the data; wait till producer produces the data.

class Shared {
	int num;
	boolean flag = false;
	synchronized int get() {    
		if(flag==false) {
				System.out.println("Waiting for data...");
				wait();
		}
		System.out.println(Thread.currentThread().getName() + " " + num);
		flag = false; //it means producer have no data
		notify();
		return num;
	}
	
	synchronized void put(int num) throws InterruptedException{
		if (flag == true) {
			System.out.println("Waiting for consumer to consume data");
			wait();
	}
	this.num = num;
	System.out.println(Thread.currentThread().getName() + " " + num);
	flag = true; //now producer have data
	notify();
}

	class Producer extends Thread{
		Shared s;
		String name;
		public Producer (Shared s, String name) {
			super(name);
			this.s = s;
			this.start();
		}		
		
		@Override
		public void run() {
			
			int i = 0;
			while(true) {
				try {
					s.put(++i);
					Thread.sleep(2000);
				}
				catch(InterruptedException e){
					e.printStackTrace();
				}
			}
}

	class Consumer extends Thread{
		Shared s;
		String name;
		public Consumer (Shared s, String name) {
			super(name);
			this.s = s;
			this.start();
		}
		
		@Override
		public void run() {
			while(true) {
				try {
					s.get();
					Thread.sleep(2000);
				}
				catch(InterruptedException e){
					e.printStackTrace();
				}
			}
		}
	}
	
public class InterThreadCommunication {

	public static void main(String[] args) {
		Shared s =new Shared();
		new Producer(s, "Producer 1");
		new Consumer(s, "Consumer 1");
	}
}