package com.cybage.multithreading;

class MyThread extends Thread {
	public MyThread(String name) {
		super(name);
	}

	@Override
	public void run() {
//		System.out.println("Program is running in Thread");
		for (int i = 0; i <= 5; i++) {
			System.out.println(Thread.currentThread().getName() + " " + i); // returns the object of currently running thread
		}
	}
}

public class ThreadDemo {

	public static void main(String[] args) {
		System.out.println(Thread.currentThread().getName()); // returns the object of currently running
		MyThread thread1 = new MyThread("Thread1");
		MyThread thread2 = new MyThread("Thread1");

		thread1.start(); // after start thread will be in runnable state, ready to run but waiting for cpu
		thread2.start();
	}
}

//once run() terminates it will in dead state.