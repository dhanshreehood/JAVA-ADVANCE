//Assignment- create 2 threads, do even n odd method; use lambda expression; use sleep method() & Join method().

package com.cybage.multithreading;

public class EvenOddThread {

	public static void main(String[] args) throws InterruptedException {
		Runnable OddThread=()->{
			
			for(int i=0; i<20; i++) {
				if(i%2!=0) {
					System.out.println("Odd number Thread: " + i);
					
					try{
						Thread.sleep(2000); //sleep method- will suspend current execution of thread for specific period. 
						}
					catch(InterruptedException e){
							e.printStackTrace();
						}
				}
			}
			
			try{
				Thread.sleep(5000); //sleep method- will suspend current execution of thread for specific period. 
				}
			catch(InterruptedException e){
					e.printStackTrace();
				}
		}; 
		
		Runnable EvenThread=()->{
			
			for(int i=0; i<20; i++) {
				if(i%2==0) {
					System.out.println("Even number Thread: " + i);
					
					try{
						Thread.sleep(2000); //sleep method- will suspend current execution of thread for specific period. 
						}
					catch(InterruptedException e){
							e.printStackTrace();
						}
				}
			}
			
			try{
				Thread.sleep(5000); //sleep method- will suspend current execution of thread for specific period. 
				}
			catch(InterruptedException e){
					e.printStackTrace();
				}
		};

		Thread oddthread = new Thread(OddThread, "Thread for odd method.");
		Thread eventhread = new Thread(EvenThread, "Thread for even method.");

		oddthread.start();
		System.out.println("Status of odd number thread started execution: " + oddthread.isAlive() + "\n");

		oddthread.join();
		System.out.println("Status of odd number thread after execution: " + oddthread.isAlive() + "\n");
		
		eventhread.start();
		System.out.println("Status of even number thread started execution: " + eventhread.isAlive() + "\n");

		eventhread.join();
		System.out.println("Status of even number thread after execution: " + eventhread.isAlive() + "\n");
	}
}