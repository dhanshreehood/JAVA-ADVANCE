package com.cybage.multithreading;

class First{
		public synchronized void display(String msg)
		{
			System.out.print("[" + msg);
			try {
				Thread.sleep(2000);
			}
			catch(InterruptedException e){
				e.printStackTrace();
			}
			
			System.out.print("]");
		}
	}

class Second extends Thread{
	String msg;
	First first;
	Second (First fp, String str) //initializing var
	{
		this.first = fp;
		this.msg=str;
		start();
	}
	public void run() {
		first.display(msg);
	}
}
	
public class SynchronizedMethod {

	public static void main(String[] args) {
	First fObj = new First();
	Second s1 = new Second(fObj,"welcome");
	Second s2 = new Second(fObj,"new");
	Second s3 = new Second(fObj,"Programmer");
	}
}