package com.cybage.sessionManagement;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class SignInServlet
 */
@WebServlet("/SignInServlet")
public class SignInServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String userName = request.getParameter("username");// we are passing input name of username
		String passWord = request.getParameter("password"); // we are passing input name of password

//		create session
		HttpSession sessionObject = request.getSession();
		System.out.println(sessionObject.isNew());
		System.out.println(sessionObject.getId());
		System.out.println(sessionObject.getCreationTime());
		System.out.println(sessionObject.getLastAccessedTime());
	
		
		if(userName.equals("admin") && passWord.equals("admin@123") ) {
			
			sessionObject.setAttribute("uName", userName);
//			RequestDispatcher method- it include round trip to the client
			RequestDispatcher dispatcher=request.getRequestDispatcher("greetServlet");
//			forward()
			dispatcher.forward(request, response); //can't be frwrd to the external resource; in case of frwrd it must be in the same application.
			}
		
		else {
			out.print("Wrong Credentials...");
//			RequestDispatcher
			RequestDispatcher dispatcher=request.getRequestDispatcher("SignIn.html");
//			include()
			dispatcher.include(request, response);
			}	


	}

}
