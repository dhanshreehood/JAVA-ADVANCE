package com.cybage.sessionManagement;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CookieDemo
 */
@WebServlet("/CookieDemo")
public class CookieDemo extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Cookie[] cookiesArray = request.getCookies();
		if(cookiesArray!=null)
		{
			for(Cookie cookie :cookiesArray)
				System.out.println("Cookie" + cookie.getValue());
		}
		else {
		Cookie cookieObj = new Cookie("sessionId", "admin@123##");
		response.addCookie(cookieObj);
		System.out.println("!st request");
		}
	}
}