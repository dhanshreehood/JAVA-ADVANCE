package com.cybage.sessionManagement;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/greetServlet")
public class greetServlet extends HttpServlet {
    
//	RequestDispatcher
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		System.out.println("is session new in greetServlet: " + session.isNew());
			out.println("Welcome" + session.getAttribute("uName"));
			out.println("<a href='TestServlet'>Click Here</a>");			
	}
}