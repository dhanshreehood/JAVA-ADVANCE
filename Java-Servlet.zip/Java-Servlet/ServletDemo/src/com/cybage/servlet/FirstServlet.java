package com.cybage.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FirstServlet
 */
//@WebServlet("/FirstHelloFromServlet") //changed the url name form FirstServlet
@WebServlet(urlPatterns = {"/hello","/FirstFilter","/FirstHelloFromServlet", "/FirstDemo", "/GreetingFromServlet"}) //adding multiple url; edit localhost url and check.

public class FirstServlet extends HttpServlet {

	String msg;
	public void Sayhello() {
		
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		out.write("Hello from Servlet!!");
		
//		Listeners
		ServletContext context=getServletContext();
		context.setAttribute("msg","Hello");
		context.setAttribute("msg","Hello from servlet");
		context.removeAttribute("msg");
		context.getAttribute(getServletName());
	}
}