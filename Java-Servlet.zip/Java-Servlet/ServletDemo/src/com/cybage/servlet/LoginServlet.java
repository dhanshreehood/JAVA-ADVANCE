package com.cybage.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/Login")
public class LoginServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String userName = request.getParameter("username");// we are passing input name of username
		String passWord = request.getParameter("password"); // we are passing input name of password
//		System.out.println(userName);
//		System.out.println(passWord);
		
//		check credentials
		if(userName.equals("admin") && passWord.equals("admin@123") ) {
//			out.print("<h1>" + "Welcome " + userName + "</h1>");

//			RequestDispatcher method- it include round trip to the client
/*			RequestDispatcher dispatcher=request.getRequestDispatcher("WelcomeServlet");
//			forward()
			dispatcher.forward(request, response); //can't be frwrd to the external resource; in case of frwrd it must be in the same application.
*/		
			
//			SendRedirect method -redirecting it to the another  page, request object will not be available to the resource; can be forwarded to the external resource
/*			ServletContext context = getServletContext();
			context.setAttribute("UName", userName);
			response.sendRedirect("WelcomeServlet");
*/
			
//			Listeners
//			ServletContext context=getServletContext();
//			context.getAttribute("username","UName");

			}
		else {
			out.print("Wrong Credentials...");
//			RequestDispatcher
/*			RequestDispatcher dispatcher=request.getRequestDispatcher("login.html");
//			include()
			dispatcher.include(request, response);
*/
			}	
	}
}