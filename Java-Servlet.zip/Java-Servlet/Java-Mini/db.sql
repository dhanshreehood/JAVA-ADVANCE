create database if not exists EMS;

use EMS;

/*
Users
*/
create table if not exists users( UserId int not null auto_increment, UserEmail varchar(255) not null unique,  UserPass varchar(30) not null, UserName varchar(30) not null, UserGender char(10) not null, UserAddress varchar(255) not null, UserMobile int(10) not null, UserRole enum('Admin','Organizer','User') not null, primary key(UserId));  
drop table users;

desc users;
/*to select admins*/

select * from users where UserRole = 1;

/*to select organisers*/

select * from users where UserRole = 2;

/*to select users*/
select * from users where UserRole = 3;


insert into users(UserEmail,UserPass,UserName,UserGender,UserAddress,UserMobile,UserRole) values("admin@mail.com","admin@123","Admin","M","Pune",922266699,'Admin');
desc users;
Select * from users;

/*
To register user
insert into users(UserEmail,UserPass,UserName,UserGender,UserAddress,UserMobile,UserRole) values(?,?,?,?,?,?,?)*/

insert into users(UserEmail,UserPass,UserName,UserGender,UserAddress,UserMobile,UserRole) values("manager@mail.com","manager@123","Manager","M","Pune",922266699,'Organizer'),("user@mail.com","user@123","User","M","Pune",922266699,'User');

insert into users(UserEmail,UserPass,UserName,UserGender,UserAddress,UserMobile,UserRole) values("random@mail.com","12345678","Random","F","Pune",576575675,'User');

insert into users(UserEmail,UserPass,UserName,UserGender,UserAddress,UserMobile,UserRole) values("atharvagu@mail.com","atharva@123","Atharva","M","Udaipur",696969696,'User');
/*Get all users with Role of User
select userId, userName, userEmail, userMobile, userAddress from users where UserRole=3/?;
*/

/*Event Categories
*/
CREATE TABLE eventcategories(
  EventCategoryId int NOT NULL AUTO_INCREMENT,
  EventCategoryName varchar(255) not null unique,
  PRIMARY KEY (`EventCategoryId`)
);
drop table eventcategories;
insert into eventcategories(EventCategoryName) values("Fair"),("Concert");
insert into eventcategories(EventCategoryName) values("Party"),("Birthday");
select * from eventcategories;

/*
Events
*/
create table if not exists events( EventId int not null auto_increment, 
EventName varchar(255) not null,
EventCategoryId int not null,
OrganizerId int not null, 
EventDate date not null default '2022-10-30', 
EventLocation varchar(255) not null, 
EventPrice int not null, 
EventRating int, 
EventDescription varchar(255) not null,
 EventAvailiability int default 1,
 primary key(EventId),
 foreign key (EventCategoryId) references eventcategories(EventCategoryId),
 foreign key (OrganizerId) references users(userId)
 /*foreign key (OrganizerName) references Company(CompanyName)*/);
 
desc events;

drop table events;

insert into events(
EventName,
EventCategoryId,
OrganizerId,
EventDate,
EventLocation,
EventPrice,
EventRating,
EventDescription,
EventAvailiability) values ("Jalsa",1,2,"2022-10-30","Pune",100,4,"Fun Fair",1);

insert into events(
EventName,
EventCategoryId,
OrganizerId,
EventDate,
EventLocation,
EventPrice,
EventRating,
EventDescription,
EventAvailiability) values ("Rangelo",2,2,"2022-10-31","Mumbai",1000,4,"Holi Hai!",1);

select * from events;



/*
Update eventategories table according to EventCategoryId
update eventcategories set EventCategoryName="Birthday Party" where EventCategoryId=5;
*/


/* !!!!!DONOT RUN!!!!!!!
truncate table eventcategories;
delete from eventcategories where EventCategoryId=4;
*/

/*
Booking Status
*/

create table if not exists bookingstatus(statusid int primary key, status enum('pending','confirm','cancelled'));
desc bookingstatus;

insert into bookingstatus values(0,"pending"),(1,"confirm"),(2,"cancelled");

select * from bookingstatus;




/*
Bookings
*/
create table if not exists Bookings(bookingId INT NOT NULL auto_increment,
  eventId INT NOT NULL,
  userId INT NOT NULL,
  status int not null default 0,
  bookingdate date not null,
  PRIMARY KEY (bookingId),
    FOREIGN KEY (eventId)
    REFERENCES events (eventId),
    FOREIGN KEY (userId)
    REFERENCES users(userId),
    FOREIGN KEY (status)
    REFERENCES bookingstatus(statusid));
    
desc Bookings;

drop table bookings;

insert into Bookings(
eventId,
userId,
bookingdate) values(1,3,"2022-10-18"),(1,3,"2022-10-19");
select * from Bookings;


/*
feedbacks
*/
create table if not exists Feedbacks(FeedbackId int auto_increment primary key, FeedbackMsg longtext, EventRating int, EventId int, UserId int, foreign key (EventId) references events(EventId), foreign key (UserId) references users(UserId));
desc Feedbacks;
drop table Feedbacks;

insert into feedbacks(FeedbackMsg,
EventRating,
EventId,
UserId) values("Good",4,1,3);

select * from feedbacks;

/*
oragniser comapny

create table if not exists Company(CompanyId int auto_increment not null, CompanyName varchar(255) unique not null, CompanyAddress varchar(255) not null, CompanyGSTNumber varchar(50), CompanyEmail varchar(50) not null unique, CompanyWebsite varchar(255), CompanyContact int(10) not null, UserId int,primary key(CompanyId), foreign key (UserId) references users(UserId)); 
desc Company;
drop table Company;

insert into Company(CompanyName,CompanyAddress,CompanyGSTNumber,CompanyEmail,CompanyWebsite,CompanyContact,UserId) values ("Dhoom","Pune",12365497,"company@mail.com","company.com",789654123,2);

select * from Company;*/
/*To do
Create Delimeter for updating availiabilty in events table after updating booking status - after insert run trigger/procedure to update
Create Delimeter for updating rating in events table after updating rating in Feedback table
*/

/*To fetch events for particular oraganiser - getAllEventsbyOrganizer(int orgId) */
select events.eventid, events.eventName, events.eventDescription, events.eventPrice, events.eventlocation, events.EventCategoryId,eventcategories.EventCategoryName, events.organizerid from events join users on  users.userId = events.organizerId join eventcategories on events.eventCategoryId = eventcategories.EventCategoryId where events.organizerid  =2;

/*Get all events - getAllEvents() */
select events.eventId , events.eventName, events.eventDescription, events.eventPrice, events.eventLocation, eventcategories.EventCategoryName as categoryName,eventcategories.EventCategoryId as categoryId, users.userId as eventOrgnaizerID from events join eventcategories on events.EventCategoryId= eventcategories.EventCategoryId join users on events.OrganizerId=users.userId;
/* get event byu id - getEventById(int eventId) */
select events.eventId , events.eventName, events.eventDescription, events.eventPrice, eventcategories.EventCategoryName as categoryName,eventcategories.EventCategoryId as categoryId, users.userId as eventOrgnaizerID, users.userName as eventOrganizerName, users.userMobile as mobilenum from events join eventcategories on events.EventCategoryId= eventcategories.EventCategoryId join users on events.OrganizerId=users.userId where eventid =1;


/* update events - updateEvents(eventBean event) */
/*
update events set eventName=?, eventDescription=?, eventPrice=?, where eventId=?;

*/

/* detelet event*/
/*
delete from events where eventId=1 /?;
*/


/*View feedback for all evenst by a particular oraginser to view at organsier dash*/

select events.eventname, events.OrganizerId , feedbacks.feedbackid , users.username, feedbacks.eventrating, feedbacks.FeedbackMsg, feedbacks.eventid, users.userid from feedbacks join users on users.userid=feedbacks.userid join events on events.eventid = feedbacks.eventid where events.organizerid =2;

/*View feedback for a particular event*/
select events.eventname, events.OrganizerId , feedbacks.feedbackid , users.username, feedbacks.eventrating, feedbacks.FeedbackMsg, feedbacks.eventid, users.userid from feedbacks join users on users.userid=feedbacks.userid join events on events.eventid = feedbacks.eventid where events.eventid=1;


/*View booking history*/
select events.organizerid, events.eventId , events.eventName,events.EventLocation, events.eventCategoryId , events.eventDescription, events.eventPrice,  users.UserName, bookingstatus.status, bookings.bookingdate from bookings join events on bookings.eventId=events.eventId join bookingstatus on bookings.status = bookingstatus.statusid join users on bookings.userId= users.userId where users.userId=3;

