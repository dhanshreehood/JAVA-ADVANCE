package com.cybage.bean;

import java.sql.Date;

public class bookingBean {
	int BookingId;
	Date BookingDate;
	int BookingStatus;
	public bookingBean() {
		super();
	}
	public bookingBean(int bookingId, Date bookingDate, int bookingStatus) {
		super();
		BookingId = bookingId;
		BookingDate = bookingDate;
		BookingStatus = bookingStatus;
	}
	@Override
	public String toString() {
		return "bookingBean [BookingId=" + BookingId + ", BookingDate=" + BookingDate + ", BookingStatus="
				+ BookingStatus + "]";
	}
	public int getBookingId() {
		return BookingId;
	}
	public void setBookingId(int bookingId) {
		BookingId = bookingId;
	}
	public Date getBookingDate() {
		return BookingDate;
	}
	public void setBookingDate(Date bookingDate) {
		BookingDate = bookingDate;
	}
	public int getBookingStatus() {
		return BookingStatus;
	}
	public void setBookingStatus(int bookingStatus) {
		BookingStatus = bookingStatus;
	}
	
}
