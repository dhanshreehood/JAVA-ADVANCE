package com.cybage.bean;

public class eventCategoryBean {
	int EventCategoryId;
	String EventCategoryName;
	public int getEventCategoryId() {
		return EventCategoryId;
	}
	public void setEventCategoryId(int eventCategoryId) {
		EventCategoryId = eventCategoryId;
	}
	public String getEventCategoryName() {
		return EventCategoryName;
	}
	public eventCategoryBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public eventCategoryBean(int eventCategoryId, String eventCategoryName) {
		super();
		EventCategoryId = eventCategoryId;
		EventCategoryName = eventCategoryName;
	}
	@Override
	public String toString() {
		return "eventCategoryBean [EventCategoryId=" + EventCategoryId + ", EventCategoryName=" + EventCategoryName
				+ "]";
	}
	public void setEventCategoryName(String eventCategoryName) {
		EventCategoryName = eventCategoryName;
	}
}
