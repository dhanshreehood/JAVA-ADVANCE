package com.cybage.bean;

public class feedbackBean {
	int feedbackId;
	String feedbackMsg;
	int eventRating;
	int userId;
	int eventId;
	String userName;
	String eventName;
	
	



	public feedbackBean(int feedbackId, String feedbackMsg, int eventRating, int userId, int eventId, String userName,
			String eventName) {
		super();
		this.feedbackId = feedbackId;
		this.feedbackMsg = feedbackMsg;
		this.eventRating = eventRating;
		this.userId = userId;
		this.eventId = eventId;
		this.userName = userName;
		this.eventName = eventName;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	@Override
	public String toString() {
		return "feedbackBean [feedbackId=" + feedbackId + ", feedbackMsg=" + feedbackMsg + ", eventRating="
				+ eventRating + ", userId=" + userId + ", eventId=" + eventId + ", userName=" + userName
				+ ", eventName=" + eventName + "]";
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public int getFeedbackId() {
		return feedbackId;
	}

	public void setFeedbackId(int feedbackId) {
		this.feedbackId = feedbackId;
	}

	public String getFeedbackMsg() {
		return feedbackMsg;
	}

	public void setFeedbackMsg(String feedbackMsg) {
		this.feedbackMsg = feedbackMsg;
	}

	public int getEventRating() {
		return eventRating;
	}

	public void setEventRating(int eventRating) {
		this.eventRating = eventRating;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getEventId() {
		return eventId;
	}

	public void setEventId(int eventId) {
		this.eventId = eventId;
	}

	public feedbackBean() {
		super();
		}

}
