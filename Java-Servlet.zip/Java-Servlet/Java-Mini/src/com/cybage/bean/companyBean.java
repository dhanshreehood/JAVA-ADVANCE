package com.cybage.bean;

public class companyBean {
	
	int CompanyId;
	 String CompanyName;
	String CompanyAddress;
	String CompanyGSTNumber;
	String CompanyEmail;
	String CompanyWebsite;
	int CompanyContact;
	public companyBean() {
		super();
	}
	public companyBean(int companyId, String companyName, String companyAddress, String companyGSTNumber,
			String companyEmail, String companyWebsite, int companyContact) {
		super();
		CompanyId = companyId;
		CompanyName = companyName;
		CompanyAddress = companyAddress;
		CompanyGSTNumber = companyGSTNumber;
		CompanyEmail = companyEmail;
		CompanyWebsite = companyWebsite;
		CompanyContact = companyContact;
	}
	@Override
	public String toString() {
		return "companyBean [CompanyId=" + CompanyId + ", CompanyName=" + CompanyName + ", CompanyAddress="
				+ CompanyAddress + ", CompanyGSTNumber=" + CompanyGSTNumber + ", CompanyEmail=" + CompanyEmail
				+ ", CompanyWebsite=" + CompanyWebsite + ", CompanyContact=" + CompanyContact + "]";
	}
	public int getCompanyId() {
		return CompanyId;
	}
	public void setCompanyId(int companyId) {
		CompanyId = companyId;
	}
	public String getCompanyName() {
		return CompanyName;
	}
	public void setCompanyName(String companyName) {
		CompanyName = companyName;
	}
	public String getCompanyAddress() {
		return CompanyAddress;
	}
	public void setCompanyAddress(String companyAddress) {
		CompanyAddress = companyAddress;
	}
	public String getCompanyGSTNumber() {
		return CompanyGSTNumber;
	}
	public void setCompanyGSTNumber(String companyGSTNumber) {
		CompanyGSTNumber = companyGSTNumber;
	}
	public String getCompanyEmail() {
		return CompanyEmail;
	}
	public void setCompanyEmail(String companyEmail) {
		CompanyEmail = companyEmail;
	}
	public String getCompanyWebsite() {
		return CompanyWebsite;
	}
	public void setCompanyWebsite(String companyWebsite) {
		CompanyWebsite = companyWebsite;
	}
	public int getCompanyContact() {
		return CompanyContact;
	}
	public void setCompanyContact(int companyContact) {
		CompanyContact = companyContact;
	}


}
