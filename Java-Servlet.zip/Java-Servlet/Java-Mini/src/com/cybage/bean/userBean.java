package com.cybage.bean;

public class userBean {
	
	int UserId;
	String UserEmail;
    String UserPass;
	String UserName;
	String UserGender;
	String UserAddress;
	int UserMobile;
	String UserRole;
	
	public userBean(int userId, String userEmail, String userPass, String userName, String userGender,
			String userAddress, int userMobile, String userRole) {
		super();
		UserId = userId;
		UserEmail = userEmail;
		UserPass = userPass;
		UserName = userName;
		UserGender = userGender;
		UserAddress = userAddress;
		UserMobile = userMobile;
		UserRole = userRole;
	}
	public userBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "userBean [UserId=" + UserId + ", UserEmail=" + UserEmail + ", UserPass=" + UserPass + ", UserName="
				+ UserName + ", UserGender=" + UserGender + ", UserAddress=" + UserAddress + ", UserMobile="
				+ UserMobile + ", UserRole=" + UserRole + "]";
	}
	public int getUserId() {
		return UserId;
	}
	public void setUserId(int userId) {
		UserId = userId;
	}
	public String getUserEmail() {
		return UserEmail;
	}
	public void setUserEmail(String userEmail) {
		UserEmail = userEmail;
	}
	public String getUserPass() {
		return UserPass;
	}
	public void setUserPass(String userPass) {
		UserPass = userPass;
	}
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getUserGender() {
		return UserGender;
	}
	public void setUserGender(String userGender) {
		UserGender = userGender;
	}
	public String getUserAddress() {
		return UserAddress;
	}
	public void setUserAddress(String userAddress) {
		UserAddress = userAddress;
	}
	public int getUserMobile() {
		return UserMobile;
	}
	public void setUserMobile(int userMobile) {
		UserMobile = userMobile;
	}
	public String getUserRole() {
		return UserRole;
	}
	public void setUserRole(String userRole) {
		UserRole = userRole;
	}
	
	

}
