package com.cybage.bean;

import java.sql.Date;

public class eventBean {
	int EventId;
	String EventName;
	String OrganizerName;
	int OrganizerId;
	int EventCategoryId;
	String eventCategoryName;
	Date EventDate;
	String EventLocation;
	int EventPrice;
	int EventRating;
	String EventDescription;
	int EventAvailiability;
	public int getEventId() {
		return EventId;
	}
	public void setEventId(int eventId) {
		EventId = eventId;
	}
	public String getEventName() {
		return EventName;
	}
	public void setEventName(String eventName) {
		EventName = eventName;
	}
	public String getOrganizerName() {
		return OrganizerName;
	}
	public void setOrganizerName(String organizerName) {
		OrganizerName = organizerName;
	}
	public int getOrganizerId() {
		return OrganizerId;
	}
	public void setOrganizerId(int organizerId) {
		OrganizerId = organizerId;
	}
	public int getEventCategoryId() {
		return EventCategoryId;
	}
	public void setEventCategoryId(int eventCategoryId) {
		EventCategoryId = eventCategoryId;
	}
	public Date getEventDate() {
		return EventDate;
	}
	public void setEventDate(java.util.Date date1) {
		EventDate = (Date) date1;
	}
	public String getEventLocation() {
		return EventLocation;
	}
	public void setEventLocation(String eventLocation) {
		EventLocation = eventLocation;
	}
	public int getEventPrice() {
		return EventPrice;
	}
	public void setEventPrice(int eventPrice) {
		EventPrice = eventPrice;
	}
	public int getEventRating() {
		return EventRating;
	}
	public void setEventRating(int eventRating) {
		EventRating = eventRating;
	}
	public String getEventDescription() {
		return EventDescription;
	}
	public void setEventDescription(String eventDescription) {
		EventDescription = eventDescription;
	}
	
	public int getEventAvailiability() {
		return EventAvailiability;
	}
	public void setEventAvailiability(int eventAvailiability) {
		EventAvailiability = eventAvailiability;
	}
	
	public eventBean(int eventId, String eventName, String organizerName, int organizerId, int eventCategoryId,
			String eventCategoryName, Date eventDate, String eventLocation, int eventPrice, int eventRating,
			String eventDescription, int eventAvailiability) {
		super();
		EventId = eventId;
		EventName = eventName;
		OrganizerName = organizerName;
		OrganizerId = organizerId;
		EventCategoryId = eventCategoryId;
		this.eventCategoryName = eventCategoryName;
		EventDate = eventDate;
		EventLocation = eventLocation;
		EventPrice = eventPrice;
		EventRating = eventRating;
		EventDescription = eventDescription;
		EventAvailiability = eventAvailiability;
	}
	@Override
	public String toString() {
		return "eventBean [EventId=" + EventId + ", EventName=" + EventName + ", OrganizerName=" + OrganizerName
				+ ", OrganizerId=" + OrganizerId + ", EventCategoryId=" + EventCategoryId + ", eventCategoryName="
				+ eventCategoryName + ", EventDate=" + EventDate + ", EventLocation=" + EventLocation + ", EventPrice="
				+ EventPrice + ", EventRating=" + EventRating + ", EventDescription=" + EventDescription
				+ ", EventAvailiability=" + EventAvailiability + "]";
	}
	public String getEventCategoryName() {
		return eventCategoryName;
	}
	public void setEventCategoryName(String eventCategoryName) {
		this.eventCategoryName = eventCategoryName;
	}
	public eventBean() {
		super();
	}


}
