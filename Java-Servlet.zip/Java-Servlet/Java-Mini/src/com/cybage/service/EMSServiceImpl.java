package com.cybage.service;

import java.util.List;

import com.cybage.bean.eventBean;
import com.cybage.bean.eventCategoryBean;
import com.cybage.bean.feedbackBean;
import com.cybage.bean.userBean;
import com.cybage.dao.EMSDAO;
import com.cybage.dao.EMSDAOImpl;

public class EMSServiceImpl implements EMSService {
	EMSDAO dao = new EMSDAOImpl();

	@Override
	public List<eventCategoryBean> getAllCategories() {

		return dao.getAllCategories();
	}

	@Override
	public boolean deleteCategory(int categoryId) {

		return dao.deleteCategory(categoryId);
	}

	@Override
	public boolean addEventCategory(eventCategoryBean category) {

		return dao.addEventCategory(category);
	}

	@Override
	public eventCategoryBean getEventCategoryById(int categoryId) {

		return dao.getEventCategoryById(categoryId);
	}

	@Override
	public boolean updateEventCategory(eventCategoryBean category) {

		return dao.updateEventCategory(category);
	}

	@Override
	public List<eventBean> getAllEventsbyOrganizer(int orgId) {

		return dao.getAllEventsbyOrganizer(orgId);
	}

	@Override
	public boolean addEvent(eventBean event) {

		return dao.addEvent(event);
	}

	@Override
	public List<eventBean> getAllEvents() {

		return dao.getAllEvents();
	}

	@Override
	public eventBean getEventById(int eventId) {

		return dao.getEventById(eventId);
	}

	@Override
	public boolean updateEvents(eventBean event) {

		return dao.updateEvents(event);
	}

	@Override
	public boolean deleteEvents(int id) {

		return dao.deleteEvents(id);
	}

	@Override
	public List<userBean> getAllEventOrganizers() {

		return dao.getAllEventOrganizers();
	}

	@Override
	public boolean insertUser(userBean users) {
		return dao.insertUser(users);
	}

	@Override
	public List<userBean> getAllUsers() {
		return dao.getAllUsers();
	}

	@Override
	public userBean userLogin(userBean user) {

		return dao.userLogin(user);
	}

	@Override
	public boolean add(userBean users) {

		return dao.insertUser(users);
	}

	@Override
	public boolean insertFeedback(feedbackBean feedback) {
		return dao.insertFeedback(feedback);
	}

	@Override
	public List<feedbackBean> viewFeedbackList(int orgId) {
		return dao.viewFeedbackList(orgId);
	}

	@Override
	public List<feedbackBean> returnFeedbackList(int eventId) {
		return dao.returnFeedbackList(eventId);
	}

	@Override
	public List<eventBean> bookedEvents(int userId) {
		return dao.bookedEvents(userId);
	}

	@Override
	public boolean bookEvent(eventBean event, userBean userId) {
		return dao.bookEvent(event, userId);
	}

}
