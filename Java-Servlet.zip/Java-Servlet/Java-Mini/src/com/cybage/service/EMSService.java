package com.cybage.service;

import java.util.List;

import com.cybage.bean.eventBean;
import com.cybage.bean.eventCategoryBean;
import com.cybage.bean.feedbackBean;
import com.cybage.bean.userBean;


public interface EMSService {
	//For admin and for insert event as well as filter event
	List<eventCategoryBean> getAllCategories();
	boolean deleteCategory(int categoryId);
	boolean addEventCategory(eventCategoryBean category);
	public eventCategoryBean getEventCategoryById(int categoryId);
	public boolean updateEventCategory(eventCategoryBean category);


	List<eventBean> getAllEventsbyOrganizer(int orgId);

	//Realted to events
	boolean addEvent(eventBean event);
	public List<eventBean> getAllEvents();
	public eventBean getEventById(int eventId);
	boolean updateEvents(eventBean event);
	boolean deleteEvents(int id);


	//for admin to view organisers
	List<userBean> getAllEventOrganizers();
	
	
	//user registration, login and update data
	public boolean insertUser(userBean users);
	public List<userBean> getAllUsers();
	public userBean userLogin(userBean user);
	//update user profile method
	boolean add(userBean users);
	
	// feedbacks
		//user to insert feedback
		public boolean insertFeedback(feedbackBean feedback);
		//for particular oragniser to view feedbacks
		public List<feedbackBean> viewFeedbackList(int orgId);
		//for particular event return all feedbacks to user view
		public List<feedbackBean> returnFeedbackList(int eventId);
		
	//Bookings	
	List<eventBean> bookedEvents(int userId);
	public boolean bookEvent(eventBean event, userBean userId);
	
	

	
}
