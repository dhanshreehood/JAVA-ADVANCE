package com.cybage.dao;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cybage.bean.eventBean;
import com.cybage.bean.eventCategoryBean;
import com.cybage.bean.feedbackBean;
import com.cybage.bean.userBean;
import com.cybage.utility.JDBCUtility;

public class EMSDAOImpl implements EMSDAO {
	/* All DAO implementations for event categories */
	/* Get list of all categories */
	static Logger logger = Logger.getLogger(EMSDAOImpl.class);

	@Override
	public List<eventCategoryBean> getAllCategories() {
		Connection connection = null;
		try {
			connection = JDBCUtility.getConnection();

		} catch (ClassNotFoundException | SQLException e1) {

			e1.printStackTrace();
		}
		List<eventCategoryBean> categoryList = new ArrayList<>();
		try (Statement stmt = connection.createStatement()) {

			ResultSet rs = stmt.executeQuery("select * from eventcategories");

			while (rs.next()) {

				eventCategoryBean category = new eventCategoryBean();
				category.setEventCategoryId(rs.getInt(1));
				category.setEventCategoryName(rs.getString(2));
				categoryList.add(category);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				JDBCUtility.closeConnection();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
		logger.setLevel(Level.DEBUG);
		logger.debug("debug msg");
		logger.debug("general info");
		logger.debug("warning msg");
		return categoryList;
	}

	/* Delete a category */
	@Override
	public boolean deleteCategory(int categoryId) {
		Connection connection = null;
		try {
			connection = JDBCUtility.getConnection();
		} catch (ClassNotFoundException | SQLException e1) {

			e1.printStackTrace();
		}
		int no = 0;
		try {
			// String deleteQuery = "delete from pms where id=?";
			String deleteQuery = "delete from eventcategories where EventCategoryId=?";
			PreparedStatement preStmt = connection.prepareStatement(deleteQuery);

			preStmt.setInt(1, categoryId);

			no = preStmt.executeUpdate();
			// //System.out.println("Number of rows affected: " + no);
			if (no > 0) {
				//System.out.println("category deleted successfully");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				JDBCUtility.closeConnection();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
		if (no > 0) {
			return true;
		} else {
			return false;
		}
	}

	/* Add a category */
	@Override
	public boolean addEventCategory(eventCategoryBean category) {
		int no = 0;
		try (Connection connection = JDBCUtility.getConnection();) {
			String insertQuery = "insert into eventcategories(EventCategoryName) values(?)";
			PreparedStatement preStmt = connection.prepareStatement(insertQuery);
			preStmt.setString(1, category.getEventCategoryName());
			no = preStmt.executeUpdate();
			//System.out.println("Number of rows affected: " + no);
			if (no > 0) {
				//System.out.println("Employee inserted successfully");
			} else {
				//System.out.println("Some error");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				JDBCUtility.closeConnection();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
		if (no > 0) {
			return true;
		} else {
			return false;
		}

	}

	/* Fetch eve nt category by event category id */
	@Override
	public eventCategoryBean getEventCategoryById(int categoryId) {
		try (Connection connection = JDBCUtility.getConnection();) {

			String query = "select * from eventcategories where EventCategoryId=?";
			PreparedStatement preStmt = connection.prepareStatement(query);
			preStmt.setInt(1, categoryId);

			ResultSet rs = preStmt.executeQuery();

			while (rs.next()) {

				eventCategoryBean category = new eventCategoryBean();
				category.setEventCategoryId(rs.getInt(1));
				category.setEventCategoryName(rs.getString(2));

				return category;

			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				JDBCUtility.closeConnection();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
		return null;
	}

	/* Update event category */
	@Override
	public boolean updateEventCategory(eventCategoryBean category) {
		int no = 0;
		try (Connection connection = JDBCUtility.getConnection();) {

			String updateQuery = "update eventcategories set EventCategoryName=? where EventCategoryId=?";
			PreparedStatement preStmt = connection.prepareStatement(updateQuery);

			preStmt.setString(1, category.getEventCategoryName());
			preStmt.setInt(2, category.getEventCategoryId());

			no = preStmt.executeUpdate();
			//System.out.println("Number of rows affected: " + no);
			if (no > 0) {
				//System.out.println("Category updated successfully");
			} else {
				//System.out.println("Some error");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				JDBCUtility.closeConnection();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
		if (no > 0) {
			return true;
		} else {
			return false;
		}

	}

	/* Admin view for list of organisers */
	@Override
	public List<userBean> getAllEventOrganizers() {
		Connection connection = null;
		try {
			connection = JDBCUtility.getConnection();
		} catch (ClassNotFoundException | SQLException e1) {

			e1.printStackTrace();
		}
		List<userBean> organizerList = new ArrayList<>();

		try (Statement stmt = connection.createStatement()) {

			ResultSet rs = stmt.executeQuery("select * from users where UserRole = 2");

			while (rs.next()) {
				userBean users = new userBean();
				users.setUserId(rs.getInt(1));
				users.setUserName(rs.getString(4));
				users.setUserEmail(rs.getString(2));
				users.setUserMobile(Integer.parseInt(rs.getString(7)));
				users.setUserAddress(rs.getString(6));
				organizerList.add(users);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				JDBCUtility.closeConnection();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
		return organizerList;
	}

	/* Event DAO */
	/* Oragniser events view */
	/* To return list of events by and specific organiser */
	@Override
	public List<eventBean> getAllEventsbyOrganizer(int orgId) {
		Connection connection = null;
		try {
			connection = JDBCUtility.getConnection();
		} catch (ClassNotFoundException | SQLException e1) {

			e1.printStackTrace();
		}
		List<eventBean> organizerEventList = new ArrayList<>();

		try (Statement stmt = connection.createStatement()) {
			String q1 = "select events.eventid, events.eventName, events.eventDescription, events.eventPrice, events.eventlocation, events.EventCategoryId,eventcategories.EventCategoryName, events.organizerid from events join users on  users.userId = events.organizerId join eventcategories on events.eventCategoryId = eventcategories.EventCategoryId where events.organizerid =?";
			PreparedStatement preStmt = connection.prepareStatement(q1);
			preStmt.setInt(1, orgId);
			ResultSet rs = preStmt.executeQuery();

			while (rs.next()) {
				eventBean events = new eventBean();
				events.setEventId(rs.getInt(1));
				events.setEventName(rs.getString(2));
				events.setEventDescription(rs.getString(3));
				events.setEventPrice(rs.getInt(4));
				events.setEventLocation(rs.getString(5));
				events.setEventCategoryId(rs.getInt(6));
				events.setEventCategoryName(rs.getString(7));
				events.setOrganizerId(rs.getInt(8));

				organizerEventList.add(events);

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				JDBCUtility.closeConnection();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
		return organizerEventList;
	}

	/* To add event */
	@Override
	public boolean addEvent(eventBean event) {
		int no = 0;
		try (Connection connection = JDBCUtility.getConnection();) {
			// //System.out.println("inside DAO");
			String insertQuery = "insert into events(EventName,EventCategoryId,OrganizerId,EventLocation,EventPrice, EventDescription) values (?,?,?,?,?,?)";
			PreparedStatement preStmt = connection.prepareStatement(insertQuery);

			preStmt.setString(1, event.getEventName());
			preStmt.setInt(2, event.getEventCategoryId());
			preStmt.setInt(3, event.getOrganizerId());
			preStmt.setString(4, event.getEventLocation());
			preStmt.setInt(5, event.getEventPrice());
			preStmt.setString(6, event.getEventDescription());

			no = preStmt.executeUpdate();

			//System.out.println("Number of rows affected: " + no);
			if (no > 0) {
				//System.out.println("inserted successfully");
			} else {
				//System.out.println("Some error");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				JDBCUtility.closeConnection();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
		if (no > 0) {
			return true;
		} else {
			return false;
		}
	}

	/* View all events for admin and user */
	@Override
	public List<eventBean> getAllEvents() {
		Connection connection = null;
		try {
			connection = JDBCUtility.getConnection();
		} catch (ClassNotFoundException | SQLException e1) {

			e1.printStackTrace();
		}
		List<eventBean> eventList = new ArrayList<>();

		try (Statement stmt = connection.createStatement()) {

			String query = "select events.eventId , events.eventName, events.eventDescription, events.eventPrice, events.eventLocation, eventcategories.EventCategoryName as categoryName,eventcategories.EventCategoryId as categoryId, users.userId as eventOrgnaizerID, users.userName as eventOrganizerName, users.userMobile as mobilenum from events join eventcategories on events.EventCategoryId= eventcategories.EventCategoryId join users on events.OrganizerId=users.userId";

			ResultSet rs = stmt.executeQuery(query);

			while (rs.next()) {

				eventBean events = new eventBean();
				events.setEventId(rs.getInt(1));
				events.setEventName(rs.getString(2));
				events.setEventDescription(rs.getString(3));
				events.setEventPrice(rs.getInt(4));
				events.setEventLocation(rs.getString(5));
				events.setEventCategoryName(rs.getString(6));
				events.setEventCategoryId(rs.getInt(7));
				events.setOrganizerId(rs.getInt(8));
				eventList.add(events);

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				JDBCUtility.closeConnection();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
		return eventList;
	}

	/* Get event by event id */
	@Override
	public eventBean getEventById(int eventId) {
		try (Connection connection = JDBCUtility.getConnection();) {

			String query = "select events.eventId , events.eventName, events.eventDescription, events.eventPrice, eventcategories.EventCategoryName as categoryName,eventcategories.EventCategoryId as categoryId, users.userId as eventOrgnaizerID, users.userName as eventOrganizerName, users.userMobile as mobilenum from events join eventcategories on events.EventCategoryId= eventcategories.EventCategoryId join users on events.OrganizerId=users.userId where eventId= ?";

			PreparedStatement preStmt = connection.prepareStatement(query);
			preStmt.setInt(1, eventId);

			ResultSet rs = preStmt.executeQuery();
			while (rs.next()) {
				eventBean events = new eventBean();
				events.setEventId(rs.getInt(1));
				events.setEventName(rs.getString(2));
				events.setEventDescription(rs.getString(3));
				events.setEventPrice(rs.getInt(4));
				events.setEventCategoryName(rs.getString(5));
				events.setEventCategoryId(rs.getInt(6));
				events.setOrganizerId(rs.getInt(7));
				events.setOrganizerName(rs.getString(8));

				return events;
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				JDBCUtility.closeConnection();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
		return null;
	}

	/* Update event */
	@Override
	public boolean updateEvents(eventBean event) {
		int no = 0;
		try (Connection connection = JDBCUtility.getConnection();) {

			// String updateQuery = "update pms set name=?, price=? where id=?";
			String updateQuery = "update events set eventName=?, eventDescription=?, eventPrice=?, where eventId=?;";
			PreparedStatement preStmt = connection.prepareStatement(updateQuery);

			preStmt.setString(1, event.getEventName());
			preStmt.setString(2, event.getEventDescription());
			preStmt.setInt(3, event.getEventPrice());
			preStmt.setInt(4, event.getEventId());

			no = preStmt.executeUpdate();
			//System.out.println("Number of rows affected: " + no);
			if (no > 0) {
				//System.out.println("Event updated successfully");
			} else {
				//System.out.println("Some error");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				JDBCUtility.closeConnection();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
		if (no > 0) {
			return true;
		} else {
			return false;
		}
	}

	/* Delete Event */
	@Override
	public boolean deleteEvents(int eventId) {
		Connection connection = null;
		try {
			connection = JDBCUtility.getConnection();
		} catch (ClassNotFoundException | SQLException e1) {

			e1.printStackTrace();
		}
		int no = 0;
		try {
			// String deleteQuery = "delete from pms where id=?";
			String deleteQuery = "delete from eventTable where eventId=?";
			PreparedStatement preStmt = connection.prepareStatement(deleteQuery);

			preStmt.setInt(1, eventId);

			no = preStmt.executeUpdate();
			//System.out.println("Number of rows affected: " + no);
			if (no > 0) {
				//System.out.println("category deleted successfully");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				JDBCUtility.closeConnection();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
		if (no > 0) {
			return true;
		} else {
			return false;
		}
	}

	/* User related DAO */
	/* Insert user/user registration code */
	@Override
	public boolean insertUser(userBean users) {
		int no = 0;

		//System.out.println("Inside dao");
		try (Connection connection = JDBCUtility.getConnection();) {
			String insertQuery = "insert into users(UserEmail,UserPass,UserName,UserGender,UserAddress,UserMobile,UserRole) values(?,?,?,?,?,?,?)";

			PreparedStatement preStmt = connection.prepareStatement(insertQuery);
			preStmt.setString(1, users.getUserEmail());
			preStmt.setString(2, users.getUserPass());
			preStmt.setString(3, users.getUserName());
			preStmt.setString(4, users.getUserGender());
			preStmt.setString(5, users.getUserAddress());
			preStmt.setInt(6, users.getUserMobile());
			preStmt.setString(7, users.getUserRole());
			no = preStmt.executeUpdate();

			//System.out.println("Number of rows affected: " + no);
			if (no > 0) {
				//System.out.println(users.getUserRole() + " inserted successfully");
			} else {
				//System.out.println("Some error");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				JDBCUtility.closeConnection();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
		if (no > 0) {
			return true;
		} else {
			return false;
		}
	}

	/* Admin view for list of all users */
	@Override
	public List<userBean> getAllUsers() {

		Connection connection = null;
		try {
			connection = JDBCUtility.getConnection();
		} catch (ClassNotFoundException | SQLException e1) {

			e1.printStackTrace();
		}
		List<userBean> userList = new ArrayList<>();

		try (Statement stmt = connection.createStatement()) {
			//System.out.println("Inside DAO");
			ResultSet rs = stmt.executeQuery(
					"select userId, userName, userEmail, userMobile, userAddress from users where UserRole=3");
			// Send it as a preparedStatement
			while (rs.next()) {
				userBean users = new userBean();
				users.setUserId(rs.getInt(1));
				users.setUserName(rs.getString(2));
				users.setUserEmail(rs.getString(3));
				users.setUserMobile(Integer.parseInt(rs.getString(4)));
				users.setUserAddress(rs.getString(5));
				userList.add(users);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				JDBCUtility.closeConnection();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
		return userList;
	}

	/* DAO logic for user login */
	@Override
	public userBean userLogin(userBean user) {

		String userEmail = user.getUserEmail();
		String password = user.getUserPass();

		//System.out.println(userEmail + " " + password);

		Connection connection = null;
		try {
			connection = JDBCUtility.getConnection();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}

		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement("SELECT * FROM users WHERE userEmail = ? and userPass = ?");
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		try {
			statement.setString(1, userEmail);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		try {
			statement.setString(2, password);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		ResultSet result = null;
		try {
			result = statement.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			if (result.next()) {
				user.setUserId(result.getInt(1));
				user.setUserName(result.getString(4));
				user.setUserRole(result.getString(8));
				user.setUserEmail(result.getString(2));
				user.setUserMobile(Integer.parseInt(result.getString(7)));
				user.setUserAddress(result.getString(6));

				//System.out.println(user.getUserName());
				//System.out.println("VERIFIED User..having role=" + user.getUserRole());
			}
		} catch (NumberFormatException | SQLException e) {
			e.printStackTrace();
		}
		try {
			JDBCUtility.closeConnection();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return user;

	}

	@Override
	public boolean insertFeedback(feedbackBean feedback) {
		int no = 0;
		try (Connection connection = JDBCUtility.getConnection();) {
			String insertQuery = "insert into feebacks(FeedbackMsg,EventRating,EventId,UserId) values(?,?,?,?,?)";
			PreparedStatement preStmt = connection.prepareStatement(insertQuery);
			preStmt.setString(2, feedback.getFeedbackMsg());
			preStmt.setInt(3, feedback.getEventRating());
			preStmt.setInt(4, feedback.getEventId());
			preStmt.setInt(5, feedback.getUserId());
			no = preStmt.executeUpdate();
			//System.out.println("Number of rows affected: " + no);
			if (no > 0) {
				//System.out.println("inserted successfully");
			} else {
				//System.out.println("Some error");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				JDBCUtility.closeConnection();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
		if (no > 0) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public List<feedbackBean> viewFeedbackList(int orgId) {
		Connection connection = null;
		try {
			connection = JDBCUtility.getConnection();
		} catch (ClassNotFoundException | SQLException e1) {

			e1.printStackTrace();
		}
		List<feedbackBean> feedbackListOrg = new ArrayList<>();
		try (Statement stmt = connection.createStatement()) {
			String fetchfeedbacks = "select events.eventname, events.OrganizerId , feedbacks.feedbackid , users.username, feedbacks.eventrating, feedbacks.FeedbackMsg, feedbacks.eventid, users.userid from feedbacks join users on users.userid=feedbacks.userid join events on events.eventid = feedbacks.eventid where events.organizerid =?";
			PreparedStatement statement1 = connection.prepareStatement(fetchfeedbacks);
			statement1.setInt(1, orgId);
			ResultSet rs = statement1.executeQuery();
			while (rs.next()) {
				feedbackBean feedback = new feedbackBean();
				feedback.setFeedbackId(rs.getInt(3));
				feedback.setFeedbackMsg(rs.getString(6));
				feedback.setUserName(rs.getString(4));
				feedback.setEventName(rs.getString(1));
				feedback.setEventRating(rs.getInt(5));
				feedbackListOrg.add(feedback);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				JDBCUtility.closeConnection();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
		return feedbackListOrg;
	}

	@Override
	public List<feedbackBean> returnFeedbackList(int eventId) {
		Connection connection = null;
		try {
			connection = JDBCUtility.getConnection();
		} catch (ClassNotFoundException | SQLException e1) {

			e1.printStackTrace();
		}
		List<feedbackBean> feedbackList = new ArrayList<>();
		try (Statement stmt = connection.createStatement()) {
			String fetchfeedbacks = "select events.eventname, events.OrganizerId , feedbacks.feedbackid , users.username, feedbacks.eventrating, feedbacks.FeedbackMsg, feedbacks.eventid, users.userid from feedbacks join users on users.userid=feedbacks.userid join events on events.eventid = feedbacks.eventid where events.eventid =?";
			PreparedStatement statement1 = connection.prepareStatement(fetchfeedbacks);
			statement1.setInt(1, eventId);
			ResultSet rs = statement1.executeQuery();
			while (rs.next()) {
				feedbackBean feedback = new feedbackBean();
				feedback.setFeedbackId(rs.getInt(3));
				feedback.setFeedbackMsg(rs.getString(6));
				feedback.setUserName(rs.getString(4));
				feedback.setEventName(rs.getString(1));
				feedback.setEventRating(rs.getInt(5));
				feedbackList.add(feedback);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				JDBCUtility.closeConnection();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
		return feedbackList;
	}

	@Override
	public List<eventBean> bookedEvents(int userId) {
		Connection connection = null;
		try {
			connection = JDBCUtility.getConnection();
		} catch (ClassNotFoundException | SQLException e1) {

			e1.printStackTrace();
		}
		List<eventBean> eventsList = new ArrayList<>();

		try (Statement stmt = connection.createStatement()) {

			String demo = " select events.organizerid, events.eventId , events.eventName,events.EventLocation, events.eventCategoryId , events.eventDescription, events.eventPrice,  users.UserName, bookingstatus.status, bookings.bookingdate from bookings join events on bookings.eventId=events.eventId join bookingstatus on bookings.status = bookingstatus.statusid join users on bookings.userId= users.userId where users.userId=?";
			PreparedStatement statement1 = connection.prepareStatement(demo);
			statement1.setInt(1, userId);
			ResultSet rs = statement1.executeQuery();
			while (rs.next()) {

				eventBean event = new eventBean();
				event.setEventId(rs.getInt(2));
				event.setEventName(rs.getString(3));
				event.setEventDescription(rs.getString(6));
				event.setEventPrice(rs.getInt(7));
				event.setEventCategoryId(rs.getInt(5));
				event.setEventAvailiability(Integer.parseInt(rs.getString(9)));
				event.setEventDate(rs.getDate(10));
				eventsList.add(event);

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				JDBCUtility.closeConnection();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
		return eventsList;
	}

	@Override
	public boolean bookEvent(eventBean event, userBean userId) {
		int no = 0;
		try (Connection connection = JDBCUtility.getConnection();) {

			String insertQuery = "insert into bookings(eventId, userId, bookingdate) values(?,?,?)";

			PreparedStatement preStmt = connection.prepareStatement(insertQuery);

			preStmt.setInt(1, event.getEventId());
			preStmt.setInt(2, userId.getUserId());
			preStmt.setDate(3, event.getEventDate());

			no = preStmt.executeUpdate();

			//System.out.println("Number of rows affected: " + no);
			if (no > 0) {
				//System.out.println("inserted successfully");
			} else {
				//System.out.println("Some error");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				JDBCUtility.closeConnection();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
		if (no > 0)
			return true;
		else
			return false;

	}

}
