package com.cybage.dao;

import java.util.List;

import com.cybage.bean.eventBean;
import com.cybage.bean.eventCategoryBean;
import com.cybage.bean.feedbackBean;
import com.cybage.bean.userBean;

public interface EMSDAO {

	// For admin and for insert event as well as filter event
	List<eventCategoryBean> getAllCategories();

	boolean deleteCategory(int categoryId);

	boolean addEventCategory(eventCategoryBean category);

	public eventCategoryBean getEventCategoryById(int categoryId);

	public boolean updateEventCategory(eventCategoryBean category);

	// get a list of all events by a particular organizer by organizerId(userId-2)
	List<eventBean> getAllEventsbyOrganizer(int orgId);

	// Realted to events
	boolean addEvent(eventBean event);

	public List<eventBean> getAllEvents();

	public eventBean getEventById(int eventId);

	boolean updateEvents(eventBean event);

	boolean deleteEvents(int id);

	// for admin to view organizers
	List<userBean> getAllEventOrganizers();

	// user registration, login and update data
	public boolean insertUser(userBean users);

	public List<userBean> getAllUsers();

	public userBean userLogin(userBean user);

	// feedbacks
	//user to insert feedback
	public boolean insertFeedback(feedbackBean feedback);
	//for particular oragnizer to view feedbacks
	public List<feedbackBean> viewFeedbackList(int orgId);
	//for particular event return all feedbacks to user view
	public List<feedbackBean> returnFeedbackList(int eventId);

	
	//bookings
	List<eventBean> bookedEvents(int userId);
	public boolean bookEvent(eventBean event,userBean userid);
	
	
}
