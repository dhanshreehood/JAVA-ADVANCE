package com.cybage.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cybage.bean.eventBean;
import com.cybage.bean.userBean;
import com.cybage.dao.EMSDAOImpl;
import com.cybage.service.EMSService;
import com.cybage.service.EMSServiceImpl;

/**
 * Servlet implementation class EventBookingController
 */
@WebServlet("/EventBookingController")
public class EventBooking extends HttpServlet {
	static Logger logger = Logger.getLogger(EMSDAOImpl.class);

	private static final long serialVersionUID = 1L;
	EMSService emsService = new EMSServiceImpl();
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		HttpSession session= request.getSession();
		int userId = (int) session.getAttribute("userId");
		out.println(userId);
		List<eventBean> userBookedEvents = emsService.bookedEvents(userId); //
		//ServletContext context = request.getServletContext();
		//System.out.println(userBookedEvents);
		request.setAttribute("userBookedEvents", userBookedEvents);
		//RequestDispatcher dispatcher = request.getRequestDispatcher("userEvents.jsp");
		RequestDispatcher dispatcher = request.getRequestDispatcher("myEvents.jsp");
		dispatcher.forward(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		eventBean event = new eventBean();
		userBean user = new userBean();
		
		PrintWriter out=response.getWriter();
		HttpSession session= request.getSession();
		int userId = (int) session.getAttribute("userId");
		out.print(userId);
		System.out.println(userId);
		
		String sDate1 = request.getParameter("eventDate");
		Date date1 = null;
		try {
			date1 = (Date) new SimpleDateFormat("dd/MM/yyyy").parse(sDate1);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		user.setUserId(userId);
		event.setEventId(Integer.parseInt(request.getParameter("eId")));
		event.setEventDate(date1);

		boolean flag = emsService.bookEvent(event,user);
		if (flag) {
			System.out.println("Booking successfully");
			 response.sendRedirect("UserEventList");
		} else {
			System.out.println("Some error.....");
			out.print("ERROR........");
		}
	}

}
