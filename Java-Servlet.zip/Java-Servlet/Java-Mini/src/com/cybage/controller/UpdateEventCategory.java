package com.cybage.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cybage.bean.eventBean;
import com.cybage.bean.eventCategoryBean;
import com.cybage.service.EMSService;
import com.cybage.service.EMSServiceImpl;

/**
 * Servlet implementation class UpdateEventCategory
 */
@WebServlet("/UpdateEventCategory")
public class UpdateEventCategory extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateEventCategory() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		EMSService emsService = new EMSServiceImpl();
		List<eventCategoryBean> categories = emsService.getAllCategories();	
		request.setAttribute("categories", categories);
		RequestDispatcher dispatcher = request.getRequestDispatcher("eventCategory.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		EMSService emsService = new EMSServiceImpl();
		eventCategoryBean category = new eventCategoryBean();
		category.setEventCategoryName(request.getParameter("categoryName"));

		boolean flag = emsService.addEventCategory(category);
		if (flag) {
			System.out.println("Record instered successfully");
			response.sendRedirect("EventCategoryController");
		} else {
			System.out.println("Some error");
		}
	}
}
