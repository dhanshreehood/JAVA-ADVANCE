package com.cybage.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cybage.bean.feedbackBean;
import com.cybage.service.EMSService;
import com.cybage.service.EMSServiceImpl;

/**
 * Servlet implementation class feedbackControllerUser
 */
@WebServlet("/feedbackUser")
public class FeedbackUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
	EMSService emsService = new EMSServiceImpl();

    /**
     * @see HttpServlet#HttpServlet()
     */
    public FeedbackUser() {
        super();
  }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session= request.getSession();
		int eventId = (int) session.getAttribute("eventId");
		List<feedbackBean> feedback = emsService.returnFeedbackList(eventId);
		request.setAttribute("feedback", feedback);
		  RequestDispatcher dispatcher = request.getRequestDispatcher("eventDetail.jsp");
		  dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		feedbackBean feedback = new feedbackBean();
		PrintWriter out=response.getWriter();
		HttpSession session= request.getSession();
		int userId = (int) session.getAttribute("userId");
		
		feedback.setUserId(userId);
		feedback.setEventRating(Integer.parseInt(request.getParameter("eventrating")));
		feedback.setEventId(Integer.parseInt(request.getParameter("eventid")));
		feedback.setFeedbackMsg(request.getParameter("feedbackmsg"));
		boolean flag = emsService.insertFeedback(feedback);
		if (flag) {
			System.out.println("Record instered successfully");
			 response.sendRedirect("AllEventsByOrganizer");
		} else {
			System.out.println("Some error.....");
			out.print("ERROR........");
		}
	
	}

}
