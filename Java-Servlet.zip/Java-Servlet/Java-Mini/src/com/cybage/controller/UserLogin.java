package com.cybage.controller;


import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cybage.bean.userBean;
import com.cybage.service.EMSService;
import com.cybage.service.EMSServiceImpl;

/**
 * Servlet implementation class UserLogin
 */
@WebServlet("/UserLogin")
public class UserLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserLogin() {
        super();
        
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		EMSService emsService = new EMSServiceImpl();
		String userEmail = request.getParameter("email");
		String userPassword = request.getParameter("password");
		userBean users = new userBean();
		
		users.setUserEmail(userEmail);
		users.setUserPass(userPassword);
		
		
		userBean loggedin = (userBean) emsService.userLogin(users);
		//System.out.println(users);
		//System.out.println(loggedin);
		
		
		HttpSession session= request.getSession();
		
		session.setAttribute("userId",loggedin.getUserId());
		session.setAttribute("userEmail", loggedin.getUserEmail());
		session.setAttribute("userName", loggedin.getUserName());
		session.setAttribute("userGender", loggedin.getUserGender());
		session.setAttribute("userAddress", loggedin.getUserAddress());
		session.setAttribute("userMobile", loggedin.getUserMobile());
		session.setAttribute("userRole", loggedin.getUserRole());
		
		//String userRoleVal = (String) session.getAttribute("userRole");
		
		//System.out.println("NAME = " + users.getUserName());
		
		if(users.getUserRole().equals("Admin"))
		{
			response.sendRedirect("adminPage.jsp");
			//System.out.println("user role = " + users.getUserRole());
		}
		else if(users.getUserRole().equals("User"))
		{
			response.sendRedirect("userPage.jsp");
			//System.out.println("user role = " + users.getUserRole());
		}
		else if(users.getUserRole().contentEquals("Organizer")) {
			response.sendRedirect("organizerPage.jsp");
			//System.out.println("user role = " + users.getUserRole());
		}
		
	}
}


