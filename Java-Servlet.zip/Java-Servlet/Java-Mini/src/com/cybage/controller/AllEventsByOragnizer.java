package com.cybage.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cybage.bean.eventBean;
import com.cybage.service.EMSService;
import com.cybage.service.EMSServiceImpl;

/**
 * Servlet implementation class AllEvents
 */
@WebServlet("/alleventsbyorg")
public class AllEventsByOragnizer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AllEventsByOragnizer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @param OrganizerId 
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		EMSService emsService = new EMSServiceImpl();
		HttpSession session= request.getSession();

		int orgid = (int) session.getAttribute("userId");
		
		List<eventBean> events = emsService.getAllEventsbyOrganizer(orgid);
		//System.out.println(events);
		request.setAttribute("eventsLIST", events);
		RequestDispatcher dispatcher = request.getRequestDispatcher("allEventsByOrganizer.jsp");
		dispatcher.forward(request, response);
		}
}
