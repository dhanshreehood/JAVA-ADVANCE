package com.cybage.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cybage.bean.userBean;
import com.cybage.service.EMSService;
import com.cybage.service.EMSServiceImpl;

/**
 * Servlet implementation class UserRegistration
 */
@WebServlet("/UserRegistration")
public class UserRegistration extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UserRegistration() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		EMSService emsService = new EMSServiceImpl();
		List<userBean> userList = emsService.getAllUsers();
		request.setAttribute("userList", userList);
		RequestDispatcher dispatcher = request.getRequestDispatcher("userList.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		userBean users = new userBean();
		EMSService emsService = new EMSServiceImpl();

		users.setUserName(request.getParameter("uName"));
		users.setUserEmail(request.getParameter("email"));
		users.setUserPass(request.getParameter("pass"));
		users.setUserMobile(Integer.parseInt(request.getParameter("mobileNumber")));
		users.setUserAddress(request.getParameter("address"));
		users.setUserRole(request.getParameter("userRole"));
		users.setUserGender(request.getParameter("gender"));
		System.out.println(request.getParameter("userRole"));

		boolean flag = emsService.insertUser(users);
		if (flag) {
			System.out.println("Record instered successfully");
			response.sendRedirect("login.jsp");
		} else {
			System.out.println("Some error on servlet");
		}

	}

}
