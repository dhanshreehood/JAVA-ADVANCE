package com.cybage.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cybage.bean.eventBean;
import com.cybage.bean.eventCategoryBean;
import com.cybage.service.EMSService;
import com.cybage.service.EMSServiceImpl;

/**
 * Servlet implementation class UpdateEvent
 */
@WebServlet("/UpdateEvent")
public class UpdateEvent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateEvent() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		EMSService emsService = new EMSServiceImpl();
		PrintWriter out = response.getWriter();
		int id = (Integer.parseInt(request.getParameter("eId")));
		out.println(id);
		eventBean events = emsService.getEventById(id);
		request.setAttribute("events", events);

		
		List<eventCategoryBean> categories = emsService.getAllCategories();
		//ServletContext context = request.getServletContext();
		request.setAttribute("categories", categories);
		

		RequestDispatcher dispatcher = request.getRequestDispatcher("updateEvent.jsp");
		dispatcher.forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		EMSService emsService = new EMSServiceImpl();

		eventBean event=new eventBean();
		event.setEventId(Integer.parseInt(request.getParameter("id")));
		event.setEventCategoryId(Integer.parseInt(request.getParameter("eventCategory")));
		event.setEventName(request.getParameter("eventName"));
		event.setEventDescription(request.getParameter("eventDescription"));
		event.setEventPrice(Integer.parseInt(request.getParameter("eventPrice")));
		
		

		boolean flag = emsService.updateEvents(event);
		if (flag) {
			System.out.println("Record updated successfully");
			response.sendRedirect("AllEventsController");
		} else {
			System.out.println("Some error");
		}
	}
}
