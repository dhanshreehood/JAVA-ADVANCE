package com.cybage.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.cybage.dao.EMSDAOImpl;
import com.cybage.service.EMSService;
import com.cybage.service.EMSServiceImpl;

/**
 * Servlet implementation class DeleteEvent
 */
@WebServlet("/DeleteEvent")
public class DeleteEvent extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger logger = Logger.getLogger(EMSDAOImpl.class);

    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteEvent() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		EMSService eMSService = new EMSServiceImpl();
		//PrintWriter out = response.getWriter();
		int id = (Integer.parseInt(request.getParameter("eId")));
		/*out.println(id);*/
		boolean flag = eMSService.deleteEvents(id);
		if (flag) {
			/*System.out.println("Record deleted successfully");
			out.println("Record deleted successfully");*/

			response.sendRedirect("AllEvents");
		} else {
			
			//System.out.println("Some error");
			logger.setLevel(Level.DEBUG);
			logger.debug("debug msg");
			logger.debug("general info");
			logger.debug("warning msg");
		}
	}


}
