package com.cybage.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cybage.bean.userBean;
import com.cybage.service.EMSService;
import com.cybage.service.EMSServiceImpl;

/**
 * Servlet implementation class EventOrganizer
 */
@WebServlet("/EventOrganizer")
public class EventOrganizer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EventOrganizer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    EMSService emsService = new EMSServiceImpl();
		List<userBean> organizerList = emsService.getAllEventOrganizers();
		request.setAttribute("organizerList", organizerList);
		RequestDispatcher dispatcher = request.getRequestDispatcher("eventOrganizerList.jsp");
		dispatcher.forward(request, response);

	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
