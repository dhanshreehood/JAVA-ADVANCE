package com.cybage.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.cybage.bean.eventBean;
import com.cybage.bean.eventCategoryBean;
import com.cybage.dao.EMSDAOImpl;
import com.cybage.service.EMSService;
import com.cybage.service.EMSServiceImpl;

/**
 * Servlet implementation class AddEvent
 */
@WebServlet("/AddEvents")
public class AddEvent extends HttpServlet {
	static Logger logger = Logger.getLogger(EMSDAOImpl.class);

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		EMSService emsService = new EMSServiceImpl();
		eventBean event = new eventBean();
		List<eventCategoryBean> categories = emsService.getAllCategories();
		//ServletContext context = request.getServletContext();
		request.setAttribute("categories", categories);
		  RequestDispatcher dispatcher = request.getRequestDispatcher("addEvent.jsp");
		  dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		eventBean event = new eventBean();
		EMSService emsService = new EMSServiceImpl();
		PrintWriter out=response.getWriter();
		HttpSession session= request.getSession();
		int orgId = (int) session.getAttribute("userId");
		
		event.setOrganizerId(orgId);
		event.setEventName(request.getParameter("eventName"));
		event.setEventDescription(request.getParameter("eventDescription"));
		event.setEventPrice(Integer.parseInt(request.getParameter("eventPrice")));
		event.setEventCategoryId(Integer.parseInt(request.getParameter("eventCategory")));
		event.setEventLocation(request.getParameter("eventLocation"));

		boolean flag = emsService.addEvent(event);
		if (flag) {
			/*System.out.println("Record instered successfully");*/
			 response.sendRedirect("AllEvents");
		} else {
			logger.setLevel(Level.DEBUG);
			logger.debug("debug msg");
			logger.debug("general info");
			logger.debug("warning msg");
			/*System.out.println("Some error.....");
			out.print("ERROR........");*/
			response.sendRedirect("addEvent.jsp");
		}
	}

}
