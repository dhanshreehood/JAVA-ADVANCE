package com.cybage.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cybage.bean.Employee;
import com.cybage.service.EmployeeService;
import com.cybage.service.EmployeeServiceImp;

/**
 * Servlet implementation class EditEmployeeController
 */
@WebServlet("/EditEmployeeController")
public class EditEmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	EmployeeService employeeService = new EmployeeServiceImp();

    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int empId=Integer.parseInt(request.getParameter("id"));
		Employee employee=employeeService.getEmployeeById(empId);
		//System.out.println("id =" +empId);
		request.setAttribute("emp", employee);
		RequestDispatcher dispatcher = request.getRequestDispatcher("editEmployee.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Employee employee = new Employee();

		employee.setId(Integer.parseInt(request.getParameter("eid")));
		employee.setName(request.getParameter("name"));
		employee.setEmail(request.getParameter("email"));
		employee.setAddress(request.getParameter("address"));
		employee.setSalary(Integer.parseInt(request.getParameter("salary")));
		
		boolean flag = employeeService.updateEmployee(employee);
		if (flag) {
			System.out.println("Record updated successfully");
			/*
			 * RequestDispatcher dispatcher =
			 * request.getRequestDispatcher("EmployeeServlet"); dispatcher.forward(request,
			 * response);
			 */
			response.sendRedirect("EmployeeServlet");
		} else {
			System.out.println("Some error");
		}
	}

}
