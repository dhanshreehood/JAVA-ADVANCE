package com.cybage.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cybage.bean.Employee;
import com.cybage.service.EmployeeService;
import com.cybage.service.EmployeeServiceImp;

/**
 * Servlet implementation class EmployeeServlet
 */
@WebServlet("/EmployeeServlet")
public class EmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	EmployeeService employeeService = new EmployeeServiceImp();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		List<Employee> empList = employeeService.getAllEmployee();
		//ServletContext context = request.getServletContext();

		request.setAttribute("empList", empList);
		RequestDispatcher dispatcher = request.getRequestDispatcher("displayEmployee.jsp");
		dispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Employee employee = new Employee();

		employee.setId(Integer.parseInt(request.getParameter("id")));
		employee.setName(request.getParameter("name"));
		employee.setEmail(request.getParameter("email"));
		employee.setAddress(request.getParameter("address"));
		employee.setSalary(Integer.parseInt(request.getParameter("salary")));

		boolean flag = employeeService.add(employee);
		if (flag) {
			System.out.println("Record inserted successfully");
			response.sendRedirect("EmployeeServlet");
		} else {
			System.out.println("Some error");
		}
	}

}