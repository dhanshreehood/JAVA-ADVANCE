package com.cybage.service;

import java.util.List;

import com.cybage.bean.Employee;

public interface EmployeeService {

	public boolean add(Employee employee);
	public Employee getEmployeeById(int employeeId);
	public List<Employee> getAllEmployee();
	public boolean deleteEmployee(int employeeId);
	public boolean updateEmployee(Employee employee);
		
}