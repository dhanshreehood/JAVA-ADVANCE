package com.cybage.service;

import java.util.List;

import com.cybage.bean.Employee;
import com.cybage.dao.EmployeeDAO;
import com.cybage.dao.EmployeeDAOImp;


public class EmployeeServiceImp implements EmployeeService {

	private EmployeeDAO employeeDao=new EmployeeDAOImp();
	
	@Override
	public boolean add(Employee employee) {
		return employeeDao.add(employee);
		 
	}

	@Override
	public Employee getEmployeeById(int employeeId) {
		return employeeDao.getEmployeeById(employeeId);
		 
	}

	@Override
	public List<Employee> getAllEmployee() {
		return 	employeeDao.getAllEmployee();
		
	}

	@Override
	public boolean deleteEmployee(int employeeId) {
		return employeeDao.deleteEmployee(employeeId);
		
	}

	@Override
	public boolean updateEmployee(Employee employee) {
		return  employeeDao.updateEmployee(employee);
		
	}

}
