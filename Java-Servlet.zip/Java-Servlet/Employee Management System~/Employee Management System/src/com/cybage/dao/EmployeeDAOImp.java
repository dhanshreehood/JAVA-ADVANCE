package com.cybage.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cybage.bean.Employee;
import com.cybage.utility.JDBCUtility;

public class EmployeeDAOImp implements EmployeeDAO {

	@Override
	public boolean add(Employee employee) {
		int no=0;
		try (Connection connection = JDBCUtility.getConnection();) {

			// String insertQuery = "insert into pms (id,name, price) values(?,?,?)";
			String insertQuery = "insert into employee (id,name, email,address,salary) values(?,?,?,?,?)";
			PreparedStatement preStmt = connection.prepareStatement(insertQuery);

			preStmt.setInt(1, employee.getId());
			preStmt.setString(2, employee.getName());
			preStmt.setString(3, employee.getEmail());
			preStmt.setString(4, employee.getAddress());
			preStmt.setInt(5, employee.getSalary());

			no = preStmt.executeUpdate();
			System.out.println("Number of rows affected: " + no);
			if (no > 0) {
				System.out.println("Employee inserted successfully");
			} else {
				System.out.println("Some error");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeConnection();
		}
		if (no >0) {
			return true;
		} else {
			return false;
		}
		
	}

	@Override
	public Employee getEmployeeById(int employeeId) {
		
		try (Connection connection = JDBCUtility.getConnection();) {

			// String query = "select * from pms where id=?";
			String query = "select * from employee where id=?";
			PreparedStatement preStmt = connection.prepareStatement(query);
			preStmt.setInt(1, employeeId);

			ResultSet rs = preStmt.executeQuery();
			int id, price;
			String name;
			while (rs.next()) {
				/*
				 * id = rs.getInt("id"); name = rs.getString("name"); price =
				 * rs.getInt("price");
				 */
				Employee employee = new Employee();
				employee.setId(rs.getInt("id"));
				employee.setName(rs.getString("name"));
				employee.setEmail(rs.getString("email"));
				employee.setAddress(rs.getString("address"));
				employee.setSalary(rs.getInt("salary"));
				return employee;
				

			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeConnection();
		}
		return null;

		
	}

	@Override
	public List<Employee> getAllEmployee() {
		Connection connection = JDBCUtility.getConnection();
		List<Employee> empList = new ArrayList<>();

		try (Statement stmt = connection.createStatement()) {

			ResultSet rs = stmt.executeQuery("select * from employee");

			while (rs.next()) {

				Employee employee = new Employee();

				employee.setId(rs.getInt(1));
				employee.setName(rs.getString(2));
				employee.setEmail(rs.getString(3));
				employee.setAddress(rs.getString(4));
				employee.setSalary(rs.getInt(5));

				empList.add(employee);				
			}

			/*
			 * for (Employee emp : empList) { System.out.println(emp); }
			 */
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeConnection();
		}
		return empList;

	}

	@Override
	public boolean deleteEmployee(int employeeId) {
		Connection connection = JDBCUtility.getConnection();
		int no=0;
		try {
			// String deleteQuery = "delete from pms where id=?";
			String deleteQuery = "delete from employee where id=?";
			PreparedStatement preStmt = connection.prepareStatement(deleteQuery);

			preStmt.setInt(1, employeeId);

			 no = preStmt.executeUpdate();
			System.out.println("Number of rows affected: " + no);
			if (no > 0) {
				System.out.println("employee deleted successfully");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeConnection();
		}
		if (no >0) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean updateEmployee(Employee employee) {
		int no=0;
		try (Connection connection = JDBCUtility.getConnection();) {

			String updateQuery = "update employee set name=?, email=?, address=?, salary=? where id=?";
			PreparedStatement preStmt = connection.prepareStatement(updateQuery);

			preStmt.setString(1, employee.getName());
			preStmt.setString(2, employee.getEmail());
			preStmt.setString(3, employee.getAddress());
			preStmt.setInt(4, employee.getSalary());
			preStmt.setInt(5, employee.getId());

			no = preStmt.executeUpdate();
			System.out.println("Number of rows affected: " + no);
			if (no > 0) {
				System.out.println("Product updated successfully");
			} else {
				System.out.println("Some error");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeConnection();
		}
		if (no >0) {
			return true;
		} else {
			return false;
		}
	}
}