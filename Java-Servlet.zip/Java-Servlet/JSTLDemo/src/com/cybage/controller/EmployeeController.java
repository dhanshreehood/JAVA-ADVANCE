package com.cybage.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cybage.model.Employee;

/**
 * Servlet implementation class EmployeeController
 */

@WebServlet("/Employee")
public class EmployeeController extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<Employee> empList =new ArrayList<Employee>(); //generic- <> in which u specify the datatype of items u gonna store in the list.
		
		empList.add(new Employee(101, "John", 440030));
		empList.add(new Employee(101, "John", 440030));
		empList.add(new Employee(101, "John", 440030));
		empList.add(new Employee(101, "John", 440030));
		empList.add(new Employee(101, "John", 440030));
		empList.add(new Employee(101, "John", 440030));
		
		
		ServletContext context=getServletContext();
		context.setAttribute("empList", empList);
		response.sendRedirect("employee.jsp");
		
		}
}
