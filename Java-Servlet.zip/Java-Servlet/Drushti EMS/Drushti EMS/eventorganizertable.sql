create database ems;

show databases;

use ems;

desc eventorganizer;

CREATE TABLE `ems`.`eventorganizer` (
  `eventId` INT NULL,
  `eventName` VARCHAR(45) NULL,
  `eventAddress` VARCHAR(200) NULL,
  `eventPrice` VARCHAR(45) NULL,
  `eventDiscription` VARCHAR(100) NULL,
  `eventStatus` VARCHAR(45) NULL,
  `eventCategory` VARCHAR(100) NULL,
  PRIMARY KEY (`eventId`));

insert into eventorganizer values(2,"Wedding","Pune",5000,"flower decoration","available","wedding") ; 
  
  
  
