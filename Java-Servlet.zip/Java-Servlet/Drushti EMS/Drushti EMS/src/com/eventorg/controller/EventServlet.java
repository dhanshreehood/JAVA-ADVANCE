package com.eventorg.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.eventorg.bean.Event;
import com.eventorg.service.EventService;
import com.eventorg.service.EventServiceImp;


@WebServlet("/EventServlet")
public class EventServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    EventService eventService = new EventServiceImp();
   

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      
//		List<AdminCategory> categoryList = adminservice.getAllCategory();
//		
//		ServletContext context=getServletContext();
//		context.setAttribute("categoryList", categoryList);
		
		
		List<Event> eventList = eventService.getAllEvent();
		request.setAttribute("eventList", eventList);
		RequestDispatcher dispatcher = request.getRequestDispatcher("displayEvent.jsp");
		dispatcher.forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Event event = new Event();

		event.setEventName(request.getParameter("eventName"));
		event.setEventCategory(request.getParameter("eventCategory"));
		event.setEventDescription(request.getParameter("eventDescription"));
		event.setEventPrice(request.getParameter("eventPrice"));
		
		System.out.println(request.getParameter("eventName"));
		
		boolean flag = eventService.add(event);
		if (flag) {
			System.out.println("Record instered successfully");
			response.sendRedirect("EventServlet");
		} else {
			System.out.println("error in servlet");
		}
	}
}