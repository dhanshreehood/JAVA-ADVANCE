package com.eventorg.service;

import java.util.List;

import com.eventorg.bean.Event;
import com.eventorg.dao.Eventdao;
import com.eventorg.dao.EventdaoImp;






public class EventServiceImp implements EventService {
  
	private Eventdao eventdao = new EventdaoImp();

	@Override
	public boolean add(Event event) {
		
		return eventdao.add(event);
	}

	@Override
	public Event getEventById(int eventId) {
		
		return eventdao.getEventById(eventId);
	}

	@Override
	public List<Event> getAllEvent() {
		
		return eventdao.getAllEvent() ;
	}

	@Override
	public boolean EventDelete(int eventId) {
		
		return eventdao.EventDelete(eventId);
	}

	@Override
	public boolean EventEdit(Event event) {
		
		return eventdao.EventEdit(event) ;
	}
	
}
