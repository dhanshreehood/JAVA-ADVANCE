package com.eventorg.service;

import java.util.List;

import com.eventorg.bean.Event;



public interface EventService {
	
	public boolean add(Event event);
	public Event getEventById(int eventId);
	public List<Event> getAllEvent();
	public boolean EventDelete(int eventId);
	public boolean EventEdit(Event event);
}
