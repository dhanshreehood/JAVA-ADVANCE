package com.eventorg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.eventorg.bean.Event;
import com.eventorg.utility.JDBCUtility;



public class EventdaoImp implements Eventdao {
	
	/* Add */
	
	public boolean add(Event event) {
		int number=0;
		try (Connection connection = JDBCUtility.getConnection();) {

			
			String insertQuery = "insert into event (eventName, eventCategory,eventDescription,eventPrice) values(?,?,?,?)";
			PreparedStatement preStmt = connection.prepareStatement(insertQuery);

			preStmt.setString(1, event.getEventName());
			preStmt.setString(2, event.getEventCategory());
			preStmt.setString(3, event.getEventDescription());
			preStmt.setString(4, event.getEventPrice());

			number = preStmt.executeUpdate();
			System.out.println("Number of rows affected: " + number);
			if (number > 0) {
				System.out.println("Event inserted successfully");
			} else {
				System.out.println("error in DAO");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeConnection();
		}
		if (number >0) {
			return true;
		} else {
			return false;
		}
		
	}

	
	
	@Override
	public Event getEventById(int eventId) {
		
		try (Connection connection = JDBCUtility.getConnection();) {

			
			String query = "select * from event where eventId=?";
			PreparedStatement preStmt = connection.prepareStatement(query);
			preStmt.setInt(1, eventId);
			

			ResultSet rs = preStmt.executeQuery();
			
			while (rs.next()) {
			
				Event event = new Event();
			
				event.setEventId(rs.getInt("eventId"));			
				event.setEventName(rs.getString("eventName"));
		        event.setEventCategory(rs.getString("eventCategory"));
		        event.setEventDescription(rs.getString("eventDescription"));
			    event.setEventPrice(rs.getString("eventPrice"));
		
				return event;
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeConnection();
		}
		return null;
	
	}

	@Override
	public List<Event> getAllEvent() {
		Connection connection = JDBCUtility.getConnection();
		List<Event> eventList = new ArrayList<>();

		try (Statement stmt = connection.createStatement()) {

			ResultSet rs = stmt.executeQuery("select * from event");

			while (rs.next()) {

				Event event = new Event();

				event.setEventId(rs.getInt(1));
				event.setEventName(rs.getString(2));
				event.setEventCategory(rs.getString(3));
				event.setEventDescription(rs.getString(4));
				event.setEventPrice(rs.getString(5));

				eventList.add(event);
	
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeConnection();
		}
		return eventList;

	}

	@Override
	public boolean EventDelete(int eventId) {
		Connection connection = JDBCUtility.getConnection();
		int number=0;
		try {
			
			String deleteQuery = "delete from event where eventId=?";
			PreparedStatement preStmt = connection.prepareStatement(deleteQuery);

			preStmt.setInt(1, eventId);

			 number = preStmt.executeUpdate();
			System.out.println("Number of rows affected: " + number);
			if (number > 0) {
				System.out.println("event deleted successfully");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeConnection();
		}
		if (number >0) {
			return true;
		} else {
			return false;
		}
	}

	public boolean EventEdit(Event event) {
		int number=0;
		try (Connection connection = JDBCUtility.getConnection();) {

		
			String updateQuery = "update event set eventName=?, eventCategory=?, eventDescription=?, eventPrice=? where eventId=?";
			PreparedStatement preStmt = connection.prepareStatement(updateQuery);

			preStmt.setString(1, event.getEventName());
			preStmt.setString(2, event.getEventCategory());
			preStmt.setString(3, event.getEventDescription());
			preStmt.setString(4, event.getEventPrice());
			preStmt.setInt(5, event.getEventId());

			number = preStmt.executeUpdate();
			System.out.println("Number of rows affected: " + number);
			if (number > 0) {
				System.out.println("event edited successfully");
			} else {
				System.out.println("error");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeConnection();
		}
		if (number >0) {
			return true;
		} else {
			return false;
		}
	}

}
