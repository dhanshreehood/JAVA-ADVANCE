package com.eventorg.bean;

public class Event {

	private int eventId;
	private String eventName;
	private String eventCategory;
	private String eventDescription;
	private String eventPrice;
	
    public Event() {
		
	}

	public Event(int eventId, String eventName, String eventCategory, String eventDescription, String eventPrice) {
		super();
		this.eventId = eventId;
		this.eventName = eventName;
		this.eventCategory = eventCategory;
		this.eventDescription = eventDescription;
		this.eventPrice = eventPrice;
	}

	public int getEventId() {
		return eventId;
	}

	public void setEventId(int eventId) {
		this.eventId = eventId;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getEventCategory() {
		return eventCategory;
	}

	public void setEventCategory(String eventCategory) {
		this.eventCategory = eventCategory;
	}

	public String getEventDescription() {
		return eventDescription;
	}

	public void setEventDescription(String eventDescription) {
		this.eventDescription = eventDescription;
	}

	public String getEventPrice() {
		return eventPrice;
	}

	public void setEventPrice(String eventPrice) {
		this.eventPrice = eventPrice;
	}

	
}
