package com.cybage.controller;

import java.io.*;
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/UserRegistrationServlet")
public class UserRegistrationServlet extends HttpServlet {
private static final long serialVersionUID = 1L;

protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	System.out.println("checkpoint 0");
	int uid = (Integer.parseInt(request.getParameter("uid")));
	String username = request.getParameter("username");
	String ufname = request.getParameter("ufname");
	String ulname = request.getParameter("ulname");
	System.out.println("checkpoint 1");
	String ucontact = request.getParameter("ucontact");
	String uemail = request.getParameter("uemail");
	String uaddress = request.getParameter("uaddress");
	String upassword = request.getParameter("upassword");
	String urepassword = request.getParameter("urepassword");
	System.out.println("checkpoint 2");

	RequestDispatcher dispatcher = null;
	Connection connection = null;
	if(upassword.equals(urepassword))
	{
	try 
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/ems","root","root");
		PreparedStatement pst = connection.prepareStatement("insert into users(uid,ufname,ulname,username,uemail,upassword,uaddress,ucontact) values(?,?,?,?,?,?,?,?)");
		System.out.println("checkpoint 3");
		pst.setInt(1, uid);
		pst.setString(2, ufname);
		pst.setString(3, ulname);
		pst.setString(4, username);
		pst.setString(5, uemail);
		pst.setString(6, upassword);
		pst.setString(7, uaddress);
		pst.setString(8, ucontact);
		System.out.println("checkpoint 4");
		int rc = pst.executeUpdate();
		if(rc > 0 ) 
		{
			dispatcher = request.getRequestDispatcher("/UserRegistration.jsp");
			request.setAttribute("status", "success");
		}
		else
		{
			request.setAttribute("status", "failed");
		}
		dispatcher.forward(request,response);
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	finally {
		try 
		{
			connection.close();
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}
	}

}
}