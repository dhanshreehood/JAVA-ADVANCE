package com.cybage.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cybage.bean.EventBooking;
import com.cybage.bean.User;
import com.cybage.service.EventService;
import com.cybage.service.EventServiceImpl;

@WebServlet("/BookEventServlet")
public class BookEventServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	EventService eventService = new EventServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ServletContext context = getServletContext();
		
		int userId = Integer.parseInt(request.getParameter("user_id"));
		int eventId = Integer.parseInt(request.getParameter("event_id"));
		
		context.setAttribute("userId", context.getAttribute("userId"));
		context.setAttribute("event_id", context.getAttribute("event_id")); 
		
		System.out.println("userId:" + userId);		
		System.out.println("this is event id: " + eventId);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        EventBooking eventBooking = new EventBooking();      
        ServletContext context =getServletContext();
        
        eventBooking.setBooking_address(request.getParameter("booking_address"));
        eventBooking.setBooking_date(request.getParameter("booking_date"));
        eventBooking.setMember_capacity(request.getParameter("member_capacity"));
        eventBooking.setEvent_id((Integer) context.getAttribute("userId"));
        eventBooking.setEvent_id((Integer) context.getAttribute("event_id"));
        
    	boolean flag = eventService.bookEvent(eventBooking);
		if (flag) {			
			System.out.println("Event booked successfully");
			request.setAttribute("eventBooking", eventBooking);
			RequestDispatcher dispatcher = request.getRequestDispatcher("showBookedEvent.jsp");
			dispatcher.forward(request, response);
		} 
		
		else {
			System.out.println("Event not booked");
			request.setAttribute("errMessage", flag);
         request.getRequestDispatcher("bookEvent.jsp").forward(request, response);//forwarding the request
		}
	}
	}