package com.cybage.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cybage.bean.EventAdding;
import com.cybage.bean.Feedback;
import com.cybage.bean.User;
import com.cybage.service.EventService;
import com.cybage.service.EventServiceImpl;

/**
 * Servlet implementation class feedbackServlet
 */
@WebServlet("/feedbackServlet")
public class FeedbackServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	EventService eventService = new EventServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<EventAdding> eventList = eventService.getAllEvent();
		ServletContext context = request.getServletContext();

		context.setAttribute("eventList", eventList);
		RequestDispatcher dispatcher = request.getRequestDispatcher("feedback.jsp");
		dispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 Feedback feedback = new Feedback();
		 feedback.setEvent_name(request.getParameter("event_name"));
		 feedback.setFeedback(request.getParameter("feedback"));
		 feedback.setRating(request.getParameter("rating"));
	          
	     	boolean flag = eventService.addFeedback(feedback);
//	        String usernameValidate = eventService.checkUsernameExists(registerBean); //Calling authenticateUser function

			if (flag) {
				System.out.println("Feedback inserted successfully");
				request.setAttribute("feedback", feedback);
				RequestDispatcher dispatcher = request.getRequestDispatcher("showFeedback.jsp");
				dispatcher.forward(request, response);
			} 
			
			else {
				System.out.println("Record not inserted.");
				request.setAttribute("errMessage", flag); //If authenticateUser() function returns other than SUCCESS string it will be sent to Login page again. Here the error message returned from function has been stored in a errMessage key.
	          request.getRequestDispatcher("feedback.jsp").forward(request, response);//forwarding the request
			}
		}
	}

}
