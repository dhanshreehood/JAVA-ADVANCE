package com.cybage.controller;
 
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cybage.bean.Admin;
import com.cybage.bean.User;
import com.cybage.dao.EventDAO;
import com.cybage.dao.EventDaoImpl;
import com.cybage.service.EventService;
import com.cybage.service.EventServiceImpl;
import com.mysql.cj.Session;
 
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	EventService eventService = new EventServiceImpl();
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int user_id=Integer.parseInt(request.getParameter("user_id"));
		User user = eventService.getUserById(user_id);

		request.setAttribute("user", user);
		RequestDispatcher dispatcher = request.getRequestDispatcher("userHome.jsp");
		dispatcher.forward(request, response);
	}
 
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//      user and event organizer
    	User user = new User(); //creating object for User class, which is a normal java class, contains just setters and getters. Bean classes are efficiently used in java to access user information wherever required in the application.
//      Here username and password are the names which I have given in the input box in Login.jsp page. Here I am retrieving the values entered by the user and keeping in instance variables for further use.
 
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String role = request.getParameter("role");
        
        user.setUsername(username); //setting the username and password through the user object then only you can get it in future.
        user.setPassword(password);
        user.setRole(role);
        
//      admin //for multiple admin
//        Admin admin = new Admin();
//        String adminUsername = request.getParameter("admin_username");
//        String adminPassword = request.getParameter("admin_password");
//        
//        admin.setAdmin_username(adminUsername);
//        admin.setAdmin_password(adminPassword);

        String userValidate = eventService.authenticateUser(user); //Calling authenticateUser function
        //String adminValidate = eventService.authenticateAdmin(admin); //Calling authenticateAdmin function

//      if(adminValidate.equals("ADMIN")) { //for multiple admin
//  	
//		HttpSession session = request.getSession();
//		session.setAttribute("admin", adminUsername);
//      request.setAttribute("admin", adminUsername); //with setAttribute() you can define a "key" and value pair so that you can get it in future using getAttribute("key")
//
//      response.sendRedirect("adminHome.jsp");
//	    }
        
        if(username.equals("admin") && password.equals("admin@123")) {      	
			HttpSession session = request.getSession();
			session.setAttribute("admin", username);
            request.setAttribute("admin", user); //with setAttribute() you can define a "key" and value pair so that you can get it in future using getAttribute("key")

            response.sendRedirect("adminHome.jsp");
        }       
        else if(userValidate.equals("EVENT_ORGANIZER")) //If function returns success and role is event organizer string then user will be rooted to Home page
         {
        	
			 System.out.println("Event Organizer loggedIn successfully");
			 
			 HttpSession session = request.getSession();
			 session.setMaxInactiveInterval(10*60);
			 session.setAttribute("eventOrganizer", username);
			 
             request.setAttribute("eventOrganizer", username); //with setAttribute() you can define a "key" and value pair so that you can get it in future using getAttribute("key")
//           request.getRequestDispatcher("UserHome.jsp").forward(request, response);//RequestDispatcher is used to send the control to the invoked page.
             response.sendRedirect("eventOrganizerHome.jsp");
         }
         
        else if(userValidate.equals("USER")) //If function returns success string and role is user then user will be rooted to Home page
        {

			 System.out.println("User loggedIn successfully");
			 
			 HttpSession session = request.getSession();
			 session.setMaxInactiveInterval(10*60);
			 session.setAttribute("user", username);
			 
            request.setAttribute("user", username); //with setAttribute() you can define a "key" and value pair so that you can get it in future using getAttribute("key")
//          request.getRequestDispatcher("UserHome.jsp").forward(request, response);//RequestDispatcher is used to send the control to the invoked page.
            response.sendRedirect("userHome.jsp");
        }

         else
         {
             request.setAttribute("errMessage", userValidate); //If authenticateUser() function returns other than SUCCESS string it will be sent to Login page again. Here the error message returned from function has been stored in a errMessage key.
             request.getRequestDispatcher("login.jsp").forward(request, response);//forwarding the request
         }
    }
}