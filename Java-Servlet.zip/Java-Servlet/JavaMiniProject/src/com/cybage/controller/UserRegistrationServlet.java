package com.cybage.controller;
import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cybage.bean.User;
import com.cybage.dao.EventDAO;
import com.cybage.service.EventService;
import com.cybage.service.EventServiceImpl;

@WebServlet("/UserRegistrationServlet")
public class UserRegistrationServlet extends HttpServlet {
  
private static final long serialVersionUID = 1L;
	
	EventService eventService = new EventServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int user_id=Integer.parseInt(request.getParameter("user_id"));
		User user = eventService.getUserById(user_id);

		request.setAttribute("user", user);
		RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
		dispatcher.forward(request, response);
	}
 
     protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
   
         User registerBean = new User();
         
        // registerBean.setUser_id(Integer.parseInt(request.getParameter("id")));
         registerBean.setFirst_name(request.getParameter("first_name"));
         registerBean.setLast_name(request.getParameter("last_name"));
         registerBean.setUsername(request.getParameter("username"));
         registerBean.setPassword(request.getParameter("password")); 
         registerBean.setEmail(request.getParameter("email"));
         registerBean.setAddress(request.getParameter("address"));
         registerBean.setContact(request.getParameter("contact"));
         registerBean.setRole(request.getParameter("role"));

          
     	boolean flag = eventService.registerUser(registerBean);
//        String usernameValidate = eventService.checkUsernameExists(registerBean); //Calling authenticateUser function

		if (flag) {
			System.out.println("User Record inserted successfully");
			request.setAttribute("user", registerBean);
			RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
			dispatcher.forward(request, response);
		} 
		
		else {
			System.out.println("Record not inserted.");
			request.setAttribute("errMessage", flag); //If authenticateUser() function returns other than SUCCESS string it will be sent to Login page again. Here the error message returned from function has been stored in a errMessage key.
          request.getRequestDispatcher("registration.jsp").forward(request, response);//forwarding the request
		}
	}
     }
