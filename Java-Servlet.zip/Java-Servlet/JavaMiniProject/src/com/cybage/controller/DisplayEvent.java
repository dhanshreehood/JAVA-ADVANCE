package com.cybage.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cybage.bean.EventAdding;
import com.cybage.bean.User;
import com.cybage.service.EventService;
import com.cybage.service.EventServiceImpl;

@WebServlet("/DisplayEvent")
public class DisplayEvent extends HttpServlet {
	private static final long serialVersionUID = 1L;
	EventService eventService = new EventServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<EventAdding> eventList = eventService.getAllEvent();
		ServletContext context = request.getServletContext();

		context.setAttribute("eventList", eventList);
		RequestDispatcher dispatcher = request.getRequestDispatcher("displayEvent.jsp");
		dispatcher.forward(request, response);
	}
}
