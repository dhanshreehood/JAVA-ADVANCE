package com.cybage.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cybage.service.EventService;
import com.cybage.service.EventServiceImpl;

@WebServlet("/CancelBookedEventServlet")
public class CancelBookedEventServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	EventService eventService = new EventServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		PrintWriter out =response.getWriter();
		int booking_id=(Integer.parseInt(request.getParameter("booking_id")));
		
		boolean flag = eventService.cancelEvent(booking_id);
		if (flag) {
			System.out.println("Event deleted successfully");
			out.println("Event deleted successfully");
			
			response.sendRedirect("showBookedEvent.jsp");
		} else {
			System.out.println("Some error");
		}
	}	

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

}
