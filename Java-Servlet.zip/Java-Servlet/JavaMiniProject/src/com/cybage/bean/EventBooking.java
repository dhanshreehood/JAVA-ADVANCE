package com.cybage.bean;

public class EventBooking {
//	event booking
	private int booking_id;
	private String booking_address;
	private String booking_date;
	private String member_capacity;
	private int event_id;
	private int userId;
	private String status;
	
//	constructor
	public EventBooking() {
		
	}
	
//	constructor using fields
	public EventBooking(int booking_id, String booking_address, String booking_date, String member_capacity,
			int event_id, int userId, String status) {
		super();
		this.booking_id = booking_id;
		this.booking_address = booking_address;
		this.booking_date = booking_date;
		this.member_capacity = member_capacity;
		this.event_id = event_id;
		this.userId = userId;
		this.status = status;
	}

	public int getEvent_id() {
		return event_id;
	}

	public void setEvent_id(int event_id) {
		this.event_id = event_id;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	//	getter and setter
	public int getBooking_id() {
		return booking_id;
	}
	public void setBooking_id(int booking_id) {
		this.booking_id = booking_id;
	}
	public String getBooking_address() {
		return booking_address;
	}
	public void setBooking_address(String booking_address) {
		this.booking_address = booking_address;
	}
	public String getBooking_date() {
		return booking_date;
	}
	public void setBooking_date(String booking_date) {
		this.booking_date = booking_date;
	}
	public String getMember_capacity() {
		return member_capacity;
	}
	public void setMember_capacity(String member_capacity) {
		this.member_capacity = member_capacity;
	}
	
}
