package com.cybage.bean;

public class Feedback {
	
//	feedback
	private int feedback_id;
	private String feedback;
	private String rating;
	private String event_name;
	
//	constructor
	public Feedback() {
		
	}
	
//	constructor using fields
	public Feedback(int feedback_id, String feedback, String rating, String event_name) {
	super();
	this.feedback_id = feedback_id;
	this.feedback = feedback;
	this.rating = rating;
	this.event_name = event_name;
}

public String getEvent_name() {
		return event_name;
	}

	public void setEvent_name(String event_name) {
		this.event_name = event_name;
	}

	//	getter and setter
	public int getFeedback_id() {
		return feedback_id;
	}
	public void setFeedback_id(int feedback_id) {
		this.feedback_id = feedback_id;
	}
	public String getFeedback() {
		return feedback;
	}
	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	
}