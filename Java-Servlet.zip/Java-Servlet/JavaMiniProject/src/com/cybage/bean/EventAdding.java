package com.cybage.bean;

public class EventAdding {
//	event added by organizer
	private int event_id;
	private String event_name;
	private String event_category;
	private String event_description;
	private String event_price;
//	private String event_status;
	private int event_organizer_id;
	
//	constructor
	public EventAdding() {
		
	}
	
//	constructor using fields
	public EventAdding(int event_id, String event_name, String event_email, String event_address, String event_category,
			String event_description, String event_image, String event_price, String event_status, int event_organizer_id) {
		super();
		this.event_id = event_id;
		this.event_name = event_name;	
		this.event_category = event_category;
		this.event_description = event_description;
		this.event_price = event_price;
//		this.event_status = event_status;
		this.event_organizer_id = event_organizer_id;
	}
	public int getEvent_organizer_id() {
		return event_organizer_id;
	}

	public void setEvent_organizer_id(int event_organizer_id) {
		this.event_organizer_id = event_organizer_id;
	}

	//	getter and setter
	public int getEvent_id() {
		return event_id;
	}
	public void setEvent_id(int event_id) {
		this.event_id = event_id;
	}
	public String getEvent_name() {
		return event_name;
	}
	public void setEvent_name(String event_name) {
		this.event_name = event_name;
	}

	public String getEvent_category() {
		return event_category;
	}
	public void setEvent_category(String event_category) {
		this.event_category = event_category;
	}
	public String getEvent_description() {
		return event_description;
	}
	public void setEvent_description(String event_description) {
		this.event_description = event_description;
	}
	public String getEvent_price() {
		return event_price;
	}
	public void setEvent_price(String event_price) {
		this.event_price = event_price;
	}
//	public String getEvent_status() {
//		return event_status;
//	}
//	public void setEvent_status(String event_status) {
//		this.event_status = event_status;
//	}

		
}