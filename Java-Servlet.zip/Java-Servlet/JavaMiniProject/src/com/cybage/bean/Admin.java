package com.cybage.bean;

public class Admin {
//	admin
	private int admin_id;
	private String admin_username;
	private String admin_email;
	private String admin_password;
	private String admin_contact;
	
//	default constructor
	public Admin() {
		
	}
	
//	constructor using fields
	public Admin(int admin_id, String admin_email, String admin_password, String admin_contact, String admin_username) {
		super();
		this.admin_id = admin_id;
		this.admin_email = admin_email;
		this.admin_password = admin_password;
		this.admin_contact = admin_contact;
		this.admin_username = admin_username;
	}
	//	getter and setter 
	public int getAdmin_id() {
		return admin_id;
	}
	public void setAdmin_id(int admin_id) {
		this.admin_id = admin_id;
	}
	public String getAdmin_email() {
		return admin_email;
	}
	public void setAdmin_email(String admin_email) {
		this.admin_email = admin_email;
	}
	public String getAdmin_password() {
		return admin_password;
	}
	public void setAdmin_password(String admin_password) {
		this.admin_password = admin_password;
	}
	public String getAdmin_contact() {
		return admin_contact;
	}
	public void setAdmin_contact(String admin_contact) {
		this.admin_contact = admin_contact;
	}

	public String getAdmin_username() {
		return admin_username;
	}

	public void setAdmin_username(String admin_username) {
		this.admin_username = admin_username;
	}

	
}
