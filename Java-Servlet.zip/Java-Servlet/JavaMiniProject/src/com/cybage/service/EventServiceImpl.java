package com.cybage.service;

import java.util.List;

import com.cybage.bean.Admin;
import com.cybage.bean.EventAdding;
import com.cybage.bean.EventBooking;
import com.cybage.bean.Feedback;
import com.cybage.bean.User;

import com.cybage.dao.EventDAO;
import com.cybage.dao.EventDaoImpl;

public class EventServiceImpl implements EventService {
	
	private EventDAO eventDao=new EventDaoImpl();

	@Override
	public boolean updateUserProfile(User user) {
			return  eventDao.updateUserProfile(user);	
	}

	@Override
	public User getUserById(int user_id) {
		return eventDao.getUserById(user_id);
	}

	@Override
	public List<User> getAllUser() {
		return eventDao.getAlluser();
	}

	@Override
	public boolean registerUser(User registerBean) {
		return eventDao.registerUser(registerBean);
	}

	@Override
	public boolean changeUserPassword(User user) {
		return eventDao.changeUserPassword(user);
	}

	@Override
	public String authenticateUser(User user) {
		return eventDao.authenticateUser(user);
	}

	@Override
	public String authenticateAdmin(Admin admin) {
		return eventDao.authenticateAdmin(admin);

	}

	@Override
	public User getUserByUsername(String username) {
		return eventDao.getUserByUsername(username);
	}

	@Override
	public List<EventAdding> getAllEvent() {
		return eventDao.getAllEvent();
	}

	@Override
	public boolean bookEvent(EventBooking eventBooking) {
		return eventDao.bookEvent(eventBooking);
	}

	@Override
	public boolean cancelEvent(int booking_id) {
		return eventDao.cancelEvent(booking_id);
	}

	@Override
	public boolean addFeedback(Feedback feedback) {
		return eventDao.addFeedback(feedback);

	}
}