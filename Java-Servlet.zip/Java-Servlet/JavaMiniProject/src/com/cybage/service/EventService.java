package com.cybage.service;

import java.util.List;

import com.cybage.bean.Admin;
import com.cybage.bean.EventAdding;
import com.cybage.bean.EventBooking;
import com.cybage.bean.Feedback;
import com.cybage.bean.User;

public interface EventService {
	public boolean updateUserProfile(User user);
	public User getUserById(int user_id);
	public boolean registerUser(User registerBean);
	public List<User> getAllUser();
	public boolean changeUserPassword(User user);
	public String authenticateUser(User user);
	public String authenticateAdmin(Admin admin);
//	public String checkUsernameExists(User registerBean);
	public User getUserByUsername(String username);
	public List<EventAdding> getAllEvent();
	public boolean bookEvent(EventBooking eventBooking);
	public boolean cancelEvent(int booking_id);
	public boolean addFeedback(Feedback feedback);
}