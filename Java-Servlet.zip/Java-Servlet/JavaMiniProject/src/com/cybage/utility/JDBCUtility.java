package com.cybage.utility;

import java.sql.Connection;
import java.sql.DriverManager;

public class JDBCUtility {

	private static Connection connection = null;

	public static Connection getConnection() {

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {

			e1.printStackTrace();
		}

		try {
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/event_management_system", "root", "root");

		} catch (Exception e) {

			e.printStackTrace();
		}

		return connection;

	}

	public static void closeConnection() {
		try {
			connection.close();
		} catch (Exception e) { 
			// TODO: handle exception
			e.printStackTrace();
		}

	}

}
