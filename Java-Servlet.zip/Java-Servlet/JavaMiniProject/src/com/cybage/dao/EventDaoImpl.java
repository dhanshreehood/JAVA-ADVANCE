package com.cybage.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cybage.bean.Admin;
import com.cybage.bean.EventAdding;
import com.cybage.bean.EventBooking;
import com.cybage.bean.Feedback;
import com.cybage.bean.User;
import com.cybage.utility.JDBCUtility;

public class EventDaoImpl implements EventDAO{
	
	 @SuppressWarnings("null")
	public String authenticateUser(User user)
     {
         String username = user.getUsername(); //Assign user entered values to temporary variables.
         String password = user.getPassword();
         String role = user.getRole();

         String userNameDB = "";
         String passwordDB = "";
         String roleDB = "";
 
         try(Connection connection = JDBCUtility.getConnection();)
         {
             //statement = con.createStatement(); //Statement is used to write queries. Read more about it.
             //resultSet = statement.executeQuery("select username, password from user"); //the table name is user and username,password are columns. Fetching all the records and storing in a resultSet.
        	 String query = "select username, password, role from user";
 			 PreparedStatement preStmt = connection.prepareStatement(query);

			ResultSet rs = preStmt.executeQuery();

             while(rs.next()) // Until next row is present otherwise it return false
             {
              userNameDB = rs.getString("username"); //fetch the values present in database
              passwordDB = rs.getString("password");
              roleDB = rs.getString("role");

             if(username.equals(userNameDB) && password.equals(passwordDB) && roleDB.equals("User"))
             {
                  return "USER"; //is user is present as a role with username and password validation it will return "USER".
             }
             else if(username.equals(userNameDB) && password.equals(passwordDB) && roleDB.equals("Event Organizer")) {
            	 return "EVENT_ORGANIZER";//is Event Organizer is present as a role with username and password validation it will return "EVENT_ORGANIZER".
             }
             }
             }
             catch(SQLException e)
             {
                e.printStackTrace();
             }finally {
     			JDBCUtility.closeConnection();
     		}
             return "Invalid user credentials"; // Return appropriate message in case of failure
         	}
     


	@Override
	public boolean updateUserProfile(User user) {	
		int no=0;
		try (Connection connection = JDBCUtility.getConnection();) {

			// String updateQuery
			String updateQuery = "update user set first_name=?, last_name=?, username=?, password=?, email=?, address=?, conya=? where id=?";
			PreparedStatement preStmt = connection.prepareStatement(updateQuery);

			preStmt.setString(1, user.getFirst_name());
			preStmt.setString(2, user.getLast_name());
			preStmt.setString(3, user.getUsername());
			preStmt.setString(4, user.getPassword());
			preStmt.setString(5, user.getEmail());
			preStmt.setString(5, user.getAddress());
			preStmt.setString(5, user.getContact());

			no = preStmt.executeUpdate();
			System.out.println("Number of rows affected: " + no);
			if (no > 0) {
				System.out.println("user profile updated successfully");
			} else {
				System.out.println("Some error");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeConnection();
		}
		if (no >0) {
			return true;
		} else {
			return false;
		}

	}

	@Override
	public User getUserById(int user_id) {
		try (Connection connection = JDBCUtility.getConnection();) {

			// String query 
			String query = "select * from user where user_id=?";
			PreparedStatement preStmt = connection.prepareStatement(query);
			preStmt.setInt(1, user_id);

			ResultSet rs = preStmt.executeQuery();
			
			while (rs.next()) {
				
				User user = new User();
				user.setUser_id(rs.getInt("user_id"));
				user.setFirst_name(rs.getString("first_name"));
				user.setLast_name(rs.getString("last_name"));
				user.setUsername(rs.getString("username"));
				user.setPassword(rs.getString("password"));
				user.setEmail(rs.getString("email"));
				user.setAddress(rs.getString("address"));
				user.setContact(rs.getString("contact"));
				user.setContact(rs.getString("role"));
				return user;
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeConnection();
		}
		return null;
	}

	@Override
	public boolean registerUser(User registerBean) {
		int rowInsertCount = 0;
		String usernameCounter = "";
		String username = registerBean.getUsername();
		int userCount;
		boolean finalInsertStatus = false;

		try (Connection connection = JDBCUtility.getConnection();) {
			PreparedStatement st = connection.prepareStatement("select count(username) from user where username = '" + username + "'");
			ResultSet r1 = st.executeQuery();
			r1.next();
			userCount = r1.getInt(1);

			if (userCount == 0) {
				String query = "insert into user(first_Name, last_Name, username, password, email, address, contact, role) values(?,?,?,?,?,?,?,?)"; // Insert
																																						// user
																																						// details
																																						// into
																																						// the
																																						// table
																																						// 'USERS'
				PreparedStatement preparedStatement = connection.prepareStatement(query); // Making use of prepared
																							// statements here to insert
																							// bunch of data
				preparedStatement.setString(1, registerBean.getFirst_name());
				preparedStatement.setString(2, registerBean.getLast_name());
				preparedStatement.setString(3, registerBean.getUsername());
				preparedStatement.setString(4, registerBean.getPassword());
				preparedStatement.setString(5, registerBean.getEmail());
				preparedStatement.setString(6, registerBean.getAddress());
				preparedStatement.setString(7, registerBean.getContact());
				preparedStatement.setString(8, registerBean.getRole());

				rowInsertCount = preparedStatement.executeUpdate();
				System.out.println("Number of rows affected: " + rowInsertCount);
				if (rowInsertCount > 0) {
					System.out.println("Registration done successfully");
					finalInsertStatus = true;
				}
			}
			else {
				System.out.println("User already exists");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeConnection();
		}
		return finalInsertStatus;

	}

	@Override
	public List<User> getAlluser() {
		Connection connection = JDBCUtility.getConnection();
		List<User> userList = new ArrayList<>();

		try (Statement stmt = connection.createStatement()) {
			ResultSet rs = stmt.executeQuery("select * from user");

			while (rs.next()) {
				User user = new User();

				user.setUser_id(rs.getInt(1));
				user.setFirst_name(rs.getString(2));
				user.setLast_name(rs.getString(3));
				user.setUsername(rs.getString(4));
				user.setPassword(rs.getString(5));
				user.setEmail(rs.getString(6));
				user.setAddress(rs.getString(7));
				user.setContact(rs.getString(8));
				user.setRole(rs.getString(9));

				userList.add(user);				
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeConnection();
		}
		return userList;
	}

	@Override
	public boolean changeUserPassword(User user) {
		int no=0;
		try (Connection connection = JDBCUtility.getConnection();) {

			// String updateQuery
			String updateQuery = "update user set password=?  where id=?";
			PreparedStatement preStmt = connection.prepareStatement(updateQuery);
		
			preStmt.setString(1, user.getUsername());
			preStmt.setString(2, user.getPassword());

			no = preStmt.executeUpdate();
			System.out.println("Number of rows affected: " + no);
			if (no > 0) {
				System.out.println("Password updated successfully");
				
			} else {
				System.out.println("Some error");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeConnection();
		}
		if (no >0) {
			return true;
		} else {
			return false;
		}
	}


	@Override
	public String authenticateAdmin(Admin admin) {
		String adminUsername = admin.getAdmin_username(); //Assign user entered values to temporary variables.
        String adminPassword = admin.getAdmin_password();

        String userNameDB = "";
        String passwordDB = "";

        try(Connection connection = JDBCUtility.getConnection();)
        {
       	 String query = "select admin_password, admin_username from admin";
			 PreparedStatement preStmt = connection.prepareStatement(query);

			ResultSet rs = preStmt.executeQuery();

            while(rs.next()) // Until next row is present otherwise it return false
            {
             userNameDB = rs.getString("admin_username"); //fetch the values present in database
             passwordDB = rs.getString("admin_password");

            if(adminUsername.equals(userNameDB) && adminPassword.equals(passwordDB))
            {
                 return "ADMIN"; //is user is present as a ADMIN with username and password validation it will return "ADMIN".
            }
           
            }
            }
            catch(SQLException e)
            {
               e.printStackTrace();
            }finally {
    			JDBCUtility.closeConnection();
    		}
            return "Invalid Admin credentials"; // Return appropriate message in case of failure
        	}



	@Override
	public User getUserByUsername(String username) {
		try (Connection connection = JDBCUtility.getConnection();) {

			// String query 
			String query = "select * from user where username=?";
			PreparedStatement preStmt = connection.prepareStatement(query);
			preStmt.setString(1, username);

			ResultSet rs = preStmt.executeQuery();
			
			while (rs.next()) {
				
				User user = new User();
				user.setFirst_name(rs.getString("first_name"));
				user.setLast_name(rs.getString("last_name"));
				user.setUsername(rs.getString("username"));
				user.setEmail(rs.getString("email"));
				user.setAddress(rs.getString("address"));
				user.setContact(rs.getString("contact"));
				return user;
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeConnection();
		}
		return null;
	}



	@Override
	public List<EventAdding> getAllEvent() {
		Connection connection = JDBCUtility.getConnection();
		List<EventAdding> eventList = new ArrayList<>();

		try (Statement stmt = connection.createStatement()) {

			ResultSet rs = stmt.executeQuery("select * from event_info");

			while (rs.next()) {

				EventAdding eventAdding = new EventAdding();
				
				eventAdding.setEvent_id(rs.getInt(1));
				eventAdding.setEvent_name(rs.getString(2));
				eventAdding.setEvent_category(rs.getString(3));
				eventAdding.setEvent_description(rs.getString(4));
				eventAdding.setEvent_price(rs.getString(5));
				eventAdding.setEvent_organizer_id(rs.getInt(6));
				
				eventList.add(eventAdding);				
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeConnection();
		}
		return eventList;
	}



	@Override
	public boolean bookEvent(EventBooking eventBooking) {
		int number=0;
		try (Connection connection = JDBCUtility.getConnection();) {

			
			String insertQuery = "insert into event_booking (booking_address, booking_date, member_capacity) values(?,?,?)";
			PreparedStatement preStmt = connection.prepareStatement(insertQuery);

			preStmt.setString(1, eventBooking.getBooking_address());
			preStmt.setString(2, eventBooking.getBooking_date());
			preStmt.setString(3, eventBooking.getMember_capacity());

			number = preStmt.executeUpdate();
			System.out.println("Number of rows affected: " + number);
			if (number > 0) {
				System.out.println("Event inserted successfully");
			} else {
				System.out.println("error in DAO");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeConnection();
		}
		if (number >0) {
			return true;
		} else {
			return false;
		}	
	}



	@Override
	public boolean cancelEvent(int booking_id) {
		Connection connection = JDBCUtility.getConnection();
		int no=0;
		try {
			String deleteQuery = "delete from event_booking where booking_id=?";
			PreparedStatement preStmt = connection.prepareStatement(deleteQuery);

			preStmt.setInt(1, booking_id);

			 no = preStmt.executeUpdate();
			System.out.println("Number of rows affected: " + no);
			if (no > 0) {
				System.out.println("booked event canceled successfully");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeConnection();
		}
		if (no >0) {
			return true;
		} else {
			return false;
		}
	}



	@Override
	public boolean addFeedback(Feedback feedback) {
		
	}
	}
	
	
	
	