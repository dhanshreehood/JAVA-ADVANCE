package com.cybage.dao;

import java.sql.SQLException;
import java.util.List;

import com.cybage.model.Product;

public interface ProductDAO {
    Product getProductById(int productId) throws ClassNotFoundException, SQLException;
	boolean addProduct(Product product) throws SQLException, ClassNotFoundException;
	List<Product> getAllProduct() throws ClassNotFoundException, SQLException;
	boolean deleteProduct(int productId) throws ClassNotFoundException, SQLException;
}
