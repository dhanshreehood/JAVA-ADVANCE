package com.cybage.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cybage.model.Product;
import com.cybage.utilities.JDBCUtilities;

public class ProductDAOImpl implements ProductDAO {

    @Override
    public Product getProductById(int productId) throws ClassNotFoundException, SQLException {
        int id = 0, cost = 0;
        String name = null;
        Connection con = JDBCUtilities.getConnection();
        final Statement st = con.createStatement();
        ResultSet resultSet = st.executeQuery("select * from productdata where pid = " + productId);
        while (resultSet.next()) {
            id = resultSet.getInt(1);
            name = resultSet.getString(2);
            cost = resultSet.getInt(3);
        }
        return new Product(id, name, cost);
    }

    @Override
    public boolean addProduct(Product product) throws SQLException, ClassNotFoundException {
        Connection con = JDBCUtilities.getConnection();
        final Statement statementToAdd = con.createStatement();
        PreparedStatement psToAdd = con.prepareStatement("insert into productdata (pname,pcost) values (?,?)");
        psToAdd.setString(1, product.getProductName());
        psToAdd.setInt(2, product.getProductCost());
        psToAdd.executeUpdate();
        return true;
    }

    @Override
    public List<Product> getAllProduct() throws ClassNotFoundException, SQLException {
        Connection con = JDBCUtilities.getConnection();
        Statement statementToGetAll = con.createStatement();
        ResultSet resultSet = statementToGetAll.executeQuery("select * from productdata");
        Product getAllProductData = new Product();
        List<Product> allProductsData = new ArrayList<>();
        while (resultSet.next()) {
            getAllProductData = new Product();
            getAllProductData.setProductId(resultSet.getInt(1));
            getAllProductData.setProductName(resultSet.getString(2));
            getAllProductData.setProductCost(resultSet.getInt(3));
            allProductsData.add(getAllProductData);
        }
        return allProductsData;
    }

    @Override
    public boolean deleteProduct(int productId) throws ClassNotFoundException, SQLException {
        Connection con = JDBCUtilities.getConnection();
        Statement statementToDelete = con.createStatement();
        int result = statementToDelete.executeUpdate("delete from productdata where pid =" + productId);
        if (result > 0)
            return true;
        else
            return false;
    }

}
