package com.cybage.ProductService;

import java.sql.SQLException;
import java.util.List;

import com.cybage.dao.ProductDAO;
import com.cybage.dao.ProductDAOImpl;
import com.cybage.model.Product;

public class ProductServicesImpl implements ProductServices {

    ProductDAO productDAO = new ProductDAOImpl();
   
	@Override
	public Product getProductById(int productId) throws ClassNotFoundException, SQLException {
		Product product = productDAO.getProductById(productId);
		return product;
	}

	@Override
	public List<Product> getAllProduct()  throws ClassNotFoundException, SQLException {
		return productDAO.getAllProduct();
	}

	@Override
	public boolean addProduct(Product product) throws ClassNotFoundException, SQLException {
		return productDAO.addProduct(product);
	}

	@Override
	public boolean deleteProduct(int productId)  throws ClassNotFoundException, SQLException {
		return productDAO.deleteProduct(productId);
	}

}
