package com.cybage.ProductService;

import java.sql.SQLException;
import java.util.List;

import com.cybage.model.Product;

public interface ProductServices {
    Product getProductById(int productId) throws ClassNotFoundException, SQLException, SQLException;
	boolean addProduct(Product product) throws ClassNotFoundException, SQLException;
	List<Product> getAllProduct() throws ClassNotFoundException, SQLException;
	boolean deleteProduct(int productId) throws ClassNotFoundException, SQLException;

}
