package com.cybage.model;

public class Product {
    private int productId;
    private String productName;
    private int productCost;

    public Product(int productId, String productName, int productCost) {
        super();
        this.productId = productId;
        this.productName = productName;
        this.productCost = productCost;
    }

    public Product() {
    }

    /**
     * @return int return the productId
     */
    public int getProductId() {
        return productId;
    }

    /**
     * @param productId the productId to set
     */
    public void setProductId(int productId) {
        this.productId = productId;
    }

    /**
     * @return String return the productName
     */
    public String getProductName() {
        return productName;
    }

    /**
     * @param productName the productName to set
     */
    public void setProductName(String productName) {
        this.productName = productName;
    }

    /**
     * @return int return the productCost
     */
    public int getProductCost() {
        return productCost;
    }

    /**
     * @param productCost the productCost to set
     */
    public void setProductCost(int productCost) {
        this.productCost = productCost;
    }

}
